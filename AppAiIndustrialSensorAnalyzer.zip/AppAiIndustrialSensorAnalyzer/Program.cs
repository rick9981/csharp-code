﻿using System;
using System.Threading.Tasks;
using AppAiIndustrialSensorAnalyzer;

namespace AppAiIndustrialSensorAnalyzer
{
    class Program
    {
        private static string RepeatChar(char c, int count) => new string(c, count);

        static async Task Main(string[] args)
        {
            Console.OutputEncoding=System.Text.Encoding.UTF8;

            Console.WriteLine("🏭 工业设备传感器数据实时分析Agent系统 v1.0");
            Console.WriteLine("==================================================");
            Console.WriteLine("正在初始化系统...\n");

            // 初始化服务
            using var sensorService = new SensorDataService();
            var aiService = new AISensorAnalysisService(sensorService);

            // 启动实时监控显示
            sensorService.StartPerformanceMonitoring(message =>
            {
                if (message.Contains("严重"))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(message);
                    Console.ResetColor();
                }
                else if (message.Contains("告警"))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(message);
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine(message);
                    Console.ResetColor();
                }
            });

            Console.WriteLine("\n✅ 系统初始化完成！");
            Console.WriteLine("\n💡 您可以询问以下类型的问题：");
            Console.WriteLine("   • 设备状态查询：\"MTR-001电机现在怎么样？\"");
            Console.WriteLine("   • 告警分析：\"有哪些严重告警需要处理？\"");
            Console.WriteLine("   • 趋势分析：\"压缩机温度趋势如何？\"");
            Console.WriteLine("   • 维护建议：\"哪些设备需要维护？\"");
            Console.WriteLine("   • 性能报告：\"生成系统性能报告\"");
            Console.WriteLine("   • 故障预测：\"预测ROB-001的故障风险\"");
            Console.WriteLine("\n输入 'exit' 退出系统\n");

            var chatHistory = new List<string>();

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("AI分析师> ");
                Console.ResetColor();

                var input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input)) continue;
                if (input.ToLower() == "exit") break;

                // 特殊命令处理
                if (input.ToLower().StartsWith("show "))
                {
                    await HandleSpecialCommands(input, sensorService);
                    continue;
                }

                try
                {
                    Console.WriteLine("\n🔍 正在分析...");
                    var response = await aiService.AnalyzeAsync(input);

                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine($"\n🤖 AI分析师:");
                    Console.WriteLine($"{response}\n");
                    Console.ResetColor();

                    // 保存对话历史
                    chatHistory.Add($"用户: {input}");
                    chatHistory.Add($"AI: {response}");

                    // 限制历史记录长度
                    if (chatHistory.Count > 20)
                    {
                        chatHistory = chatHistory.Skip(10).ToList();
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"\n❌ 分析错误: {ex.Message}");
                    Console.WriteLine("请检查网络连接或重新输入问题\n");
                    Console.ResetColor();
                }
            }

            Console.WriteLine("👋 感谢使用工业设备传感器数据分析系统！");
        }

        private static async Task HandleSpecialCommands(string input, SensorDataService sensorService)
        {
            var command = input.ToLower();

            if (command == "show devices")
            {
                ShowDeviceList(sensorService);
            }
            else if (command == "show alerts")
            {
                ShowActiveAlerts(sensorService);
            }
            else if (command == "show stats")
            {
                ShowSystemStatistics(sensorService);
            }
            else if (command.StartsWith("show device "))
            {
                var deviceId = input.Substring("show device ".Length).Trim();
                ShowDeviceDetails(sensorService, deviceId);
            }
            else
            {
                Console.WriteLine("❓ 未知命令。可用命令：");
                Console.WriteLine("   show devices  - 显示所有设备");
                Console.WriteLine("   show alerts   - 显示活跃告警");
                Console.WriteLine("   show stats    - 显示系统统计");
                Console.WriteLine("   show device [ID] - 显示设备详情");
            }
        }

        private static void ShowDeviceList(SensorDataService sensorService)
        {
            var devices = sensorService.GetAllDevices();

            Console.WriteLine("\n📋 设备列表:");
            Console.WriteLine(RepeatChar('=', 80));
            Console.WriteLine($"{"设备ID",-12} {"设备名称",-20} {"类型",-12} {"状态",-10} {"健康度",-8} {"位置",-15}");
            Console.WriteLine(RepeatChar('=', 80));


            foreach (var device in devices)
            {
                var healthColor = device.OverallHealthScore >= 80 ? ConsoleColor.Green :
                                device.OverallHealthScore >= 60 ? ConsoleColor.Yellow : ConsoleColor.Red;

                Console.Write($"{device.DeviceId,-12} {device.DeviceName,-20} {device.DeviceType,-12} {device.Status,-10} ");
                Console.ForegroundColor = healthColor;
                Console.Write($"{device.OverallHealthScore:F1}%");
                Console.ResetColor();
                Console.WriteLine($"    {device.Location,-15}");
            }
            Console.WriteLine();
        }

        private static void ShowActiveAlerts(SensorDataService sensorService)
        {
            var alerts = sensorService.GetActiveAlerts().Take(10).ToList();

            if (!alerts.Any())
            {
                Console.WriteLine("\n✅ 当前没有活跃告警\n");
                return;
            }

            Console.WriteLine($"\n⚠️  活跃告警 (显示最新{alerts.Count}条):");
            Console.WriteLine(RepeatChar('=', 100));


            foreach (var alert in alerts)
            {
                var levelColor = alert.Level switch
                {
                    AlarmLevel.Critical => ConsoleColor.Red,
                    AlarmLevel.Warning => ConsoleColor.Yellow,
                    AlarmLevel.Emergency => ConsoleColor.Magenta,
                    _ => ConsoleColor.White
                };

                Console.ForegroundColor = levelColor;
                Console.Write($"[{alert.Level}] ");
                Console.ResetColor();
                Console.Write($"{alert.DeviceName} - {alert.SensorName}: ");
                Console.WriteLine($"{alert.Message}");
                Console.WriteLine($"    时间: {alert.Timestamp:yyyy-MM-dd HH:mm:ss}, 持续: {alert.Duration.TotalMinutes:F0}分钟");
                Console.WriteLine($"    建议: {alert.RecommendedAction}");
                Console.WriteLine();
            }
        }

        private static void ShowSystemStatistics(SensorDataService sensorService)
        {
            var stats = sensorService.GetRealTimeStatistics();

            Console.WriteLine("\n📊 系统实时统计:");
            Console.WriteLine(RepeatChar('=', 50));
            Console.WriteLine($"设备总数:     {stats.TotalDevices}");
            Console.WriteLine($"活跃设备:     {stats.ActiveDevices}");
            Console.WriteLine($"设备可用性:   {(double)stats.ActiveDevices / stats.TotalDevices:P1}");
            Console.WriteLine($"传感器总数:   {stats.TotalSensors}");
            Console.WriteLine($"活跃传感器:   {stats.ActiveSensors}");
            Console.WriteLine($"平均健康度:   {stats.AverageDeviceHealth:F1}%");
            Console.WriteLine($"活跃告警:     {stats.ActiveAlertsCount}");
            Console.WriteLine($"严重告警:     {stats.CriticalAlertsCount}");
            Console.WriteLine($"过去1分钟读数: {stats.ReadingsLastMinute}");
            Console.WriteLine($"过去1小时读数: {stats.ReadingsLastHour}");
            Console.WriteLine();

            if (stats.DeviceStatusDistribution.Any())
            {
                Console.WriteLine("设备状态分布:");
                foreach (var kvp in stats.DeviceStatusDistribution)
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value}台");
                }
                Console.WriteLine();
            }
        }

        private static void ShowDeviceDetails(SensorDataService sensorService, string deviceId)
        {
            var device = sensorService.GetAllDevices().FirstOrDefault(d =>
                d.DeviceId.Equals(deviceId, StringComparison.OrdinalIgnoreCase));

            if (device == null)
            {
                Console.WriteLine($"\n❌ 未找到设备: {deviceId}");
                Console.WriteLine("可用设备ID:");
                foreach (var d in sensorService.GetAllDevices())
                {
                    Console.WriteLine($"  {d.DeviceId} - {d.DeviceName}");
                }
                Console.WriteLine();
                return;
            }

            Console.WriteLine($"\n🔍 设备详情: {device.DeviceName}");
            Console.WriteLine(RepeatChar('=', 60));
            Console.WriteLine($"设备ID:       {device.DeviceId}");
            Console.WriteLine($"设备类型:     {device.DeviceType}");
            Console.WriteLine($"制造商:       {device.Manufacturer}");
            Console.WriteLine($"型号:         {device.Model}");
            Console.WriteLine($"状态:         {device.Status}");
            Console.WriteLine($"健康度:       {device.OverallHealthScore:F1}%");
            Console.WriteLine($"运行时间:     {device.OperationHours:N0} 小时");
            Console.WriteLine($"位置:         {device.Location}");
            Console.WriteLine($"安装日期:     {device.InstallationDate:yyyy-MM-dd}");
            Console.WriteLine($"上次维护:     {device.LastMaintenanceDate:yyyy-MM-dd}");
            Console.WriteLine();

            Console.WriteLine("传感器列表:");
            Console.WriteLine(RepeatChar('=', 60));
            foreach (var sensor in device.Sensors)
            {
                var activeStatus = sensor.IsActive ? "✅" : "❌";
                Console.WriteLine($"{activeStatus} {sensor.SensorName} ({sensor.SensorType})");
                Console.WriteLine($"    范围: {sensor.MinValue}-{sensor.MaxValue} {sensor.Unit}");
                Console.WriteLine($"    正常: {sensor.NormalRangeMin}-{sensor.NormalRangeMax} {sensor.Unit}");
                Console.WriteLine($"    精度: ±{sensor.Accuracy} {sensor.Unit}");
            }
            Console.WriteLine();

            // 显示最近的告警
            var recentAlerts = sensorService.GetActiveAlerts()
                .Where(a => a.DeviceId == device.DeviceId)
                .Take(5)
                .ToList();

            if (recentAlerts.Any())
            {
                Console.WriteLine("当前告警:");
                Console.WriteLine(RepeatChar('=', 60));
                foreach (var alert in recentAlerts)
                {
                    var levelColor = alert.Level switch
                    {
                        AlarmLevel.Critical => ConsoleColor.Red,
                        AlarmLevel.Warning => ConsoleColor.Yellow,
                        _ => ConsoleColor.White
                    };

                    Console.ForegroundColor = levelColor;
                    Console.Write($"[{alert.Level}] ");
                    Console.ResetColor();
                    Console.WriteLine($"{alert.SensorName}: {alert.Message}");
                }
                Console.WriteLine();
            }
        }
    }
}