﻿using System;
using System.ComponentModel;
using System.Text.Json;
using System.Threading.Tasks;
using AppAiIndustrialSensorAnalyzer;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;

namespace AppAiIndustrialSensorAnalyzer
{
    public class AISensorAnalysisService
    {
        private readonly Kernel _kernel;
        private readonly SensorDataService _sensorService;

        public AISensorAnalysisService(SensorDataService sensorService)
        {
            _sensorService = sensorService;
            _kernel = InitializeKernel();
            RegisterSensorAnalysisPlugins();
        }

        private Kernel InitializeKernel()
        {
            var kernelBuilder = Kernel.CreateBuilder();

            kernelBuilder.AddOpenAIChatCompletion(
                modelId: "deepseek-chat",
                apiKey: Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY") ?? "sk-xxxx",
                endpoint: new Uri("https://api.deepseek.com/v1")
            );

            return kernelBuilder.Build();
        }

        private void RegisterSensorAnalysisPlugins()
        {
            // 🏭 设备状态总览插件  
            var deviceOverviewFunction = _kernel.CreateFunctionFromMethod(
                method: () =>
                {
                    var devices = _sensorService.GetAllDevices();
                    var stats = _sensorService.GetRealTimeStatistics();

                    var overview = new
                    {
                        SystemOverview = stats,
                        DeviceDetails = devices.Select(d => new
                        {
                            d.DeviceId,
                            d.DeviceName,
                            d.DeviceType,
                            d.Status,
                            d.OverallHealthScore,
                            d.OperationHours,
                            d.Location,
                            SensorCount = d.Sensors.Count,
                            ActiveSensors = d.Sensors.Count(s => s.IsActive)
                        }).ToList()
                    };

                    return JsonSerializer.Serialize(overview, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "GetDeviceOverview",
                description: "获取所有工业设备的状态总览，包括设备健康度、运行状态、传感器数量等"
            );

            // 📊 传感器数据分析插件  
            var sensorDataFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("设备ID，如MTR-001")] string deviceId = "",
                        [Description("传感器类型：Temperature, Pressure, Vibration, Flow, Speed, Current")] string sensorType = "",
                        [Description("时间范围（小时数）")] int hours = 1) =>
                {
                    var timeSpan = TimeSpan.FromHours(hours);

                    List<SensorReading> readings;
                    if (!string.IsNullOrEmpty(deviceId))
                    {
                        readings = _sensorService.GetRecentReadingsForDevice(deviceId, timeSpan);
                    }
                    else
                    {
                        readings = _sensorService.GetAllSensorReadings()
                            .Where(r => (DateTime.Now - r.Timestamp) <= timeSpan)
                            .ToList();
                    }

                    if (!string.IsNullOrEmpty(sensorType) && Enum.TryParse<SensorType>(sensorType, out var type))
                    {
                        readings = readings.Where(r => r.SensorType == type).ToList();
                    }

                    var analysis = readings.GroupBy(r => new { r.DeviceId, r.SensorId })
                        .Select(g => new
                        {
                            DeviceId = g.Key.DeviceId,
                            SensorId = g.Key.SensorId,
                            SensorName = g.First().SensorName,
                            SensorType = g.First().SensorType,
                            ReadingCount = g.Count(),
                            LatestValue = g.OrderByDescending(r => r.Timestamp).First().Value,
                            LatestTimestamp = g.OrderByDescending(r => r.Timestamp).First().Timestamp,
                            AverageValue = g.Average(r => r.Value),
                            MinValue = g.Min(r => r.Value),
                            MaxValue = g.Max(r => r.Value),
                            StandardDeviation = CalculateStandardDeviation(g.Select(r => r.Value).ToArray()),
                            NormalRangeMin = g.First().NormalRangeMin,
                            NormalRangeMax = g.First().NormalRangeMax,
                            OutOfRangeCount = g.Count(r => r.Value < r.NormalRangeMin || r.Value > r.NormalRangeMax),
                            AbnormalReadings = g.Where(r => r.AlarmLevel != AlarmLevel.Normal).Select(r => new
                            {
                                r.Timestamp,
                                r.Value,
                                r.AlarmLevel
                            }).ToList()
                        }).ToList();

                    return JsonSerializer.Serialize(analysis, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "AnalyzeSensorData",
                description: "分析指定设备或传感器类型的历史数据，包括统计分析、趋势分析和异常检测"
            );

            // ⚠️ 告警分析插件  
            var alertAnalysisFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("告警级别：Normal, Warning, Critical, Emergency")] string severity = "",
                        [Description("设备ID")] string deviceId = "",
                        [Description("是否只显示未解决的告警")] bool onlyActive = true) =>
                {
                    var alerts = onlyActive ? _sensorService.GetActiveAlerts() : _sensorService.GetAllAlerts();

                    if (!string.IsNullOrEmpty(severity) && Enum.TryParse<AlarmLevel>(severity, out var level))
                    {
                        alerts = alerts.Where(a => a.Level == level).ToList();
                    }

                    if (!string.IsNullOrEmpty(deviceId))
                    {
                        alerts = alerts.Where(a => a.DeviceId == deviceId).ToList();
                    }

                    var alertAnalysis = new
                    {
                        TotalAlerts = alerts.Count,
                        AlertsByLevel = alerts.GroupBy(a => a.Level).ToDictionary(g => g.Key.ToString(), g => g.Count()),
                        AlertsByDevice = alerts.GroupBy(a => a.DeviceName).ToDictionary(g => g.Key, g => g.Count()),
                        AlertsBySensorType = alerts.GroupBy(a => a.SensorType).ToDictionary(g => g.Key.ToString(), g => g.Count()),
                        RecentAlerts = alerts.OrderByDescending(a => a.Timestamp).Take(10).Select(a => new
                        {
                            a.DeviceName,
                            a.SensorName,
                            a.Level,
                            a.CurrentValue,
                            a.ThresholdValue,
                            a.Message,
                            a.RecommendedAction,
                            a.Timestamp,
                            a.Duration,
                            a.IsAcknowledged
                        }).ToList(),
                        LongestDurationAlerts = alerts.Where(a => a.Duration.TotalHours > 1)
                            .OrderByDescending(a => a.Duration)
                            .Take(5)
                            .Select(a => new
                            {
                                a.DeviceName,
                                a.SensorName,
                                a.Message,
                                DurationHours = a.Duration.TotalHours
                            }).ToList()
                    };

                    return JsonSerializer.Serialize(alertAnalysis, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "AnalyzeAlerts",
                description: "分析系统告警情况，包括告警统计、分布、趋势和长期未解决的告警"
            );

            // 🔍 设备健康诊断插件  
            var healthDiagnosisFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("设备ID")] string deviceId) =>
                {
                    var healthReport = _sensorService.GenerateDeviceHealthReport(deviceId);
                    if (healthReport == null)
                        return "未找到指定设备";

                    var predictiveResult = _sensorService.PredictDeviceFailure(deviceId);

                    var diagnosis = new
                    {
                        DeviceInfo = new
                        {
                            healthReport.DeviceId,
                            healthReport.DeviceName,
                            healthReport.Status,
                            healthReport.OverallHealthScore
                        },
                        HealthMetrics = healthReport.SensorMetrics.Select(m => new
                        {
                            m.SensorName,
                            m.SensorType,
                            m.HealthScore,
                            m.AverageValue,
                            m.StandardDeviation,
                            m.TrendSlope,
                            m.AnomalyCount,
                            TrendDescription = m.TrendSlope > 0.1 ? "上升趋势" :
                                             m.TrendSlope < -0.1 ? "下降趋势" : "稳定",
                            StabilityDescription = m.StandardDeviation < 1 ? "稳定" :
                                                 m.StandardDeviation < 3 ? "轻微波动" : "波动较大"
                        }).ToList(),
                        MaintenanceInfo = new
                        {
                            healthReport.PredictedNextMaintenance,
                            healthReport.RemainingUsefulLife,
                            healthReport.MaintenanceRecommendations
                        },
                        PredictiveAnalysis = predictiveResult != null ? new
                        {
                            predictiveResult.FailureProbability,
                            predictiveResult.PredictedFailureDate,
                            predictiveResult.FailureMode,
                            predictiveResult.ContributingFactors,
                            predictiveResult.PreventiveActions,
                            predictiveResult.ConfidenceLevel
                        } : null,
                        ActiveAlerts = healthReport.ActiveAlerts.Select(a => new
                        {
                            a.Level,
                            a.Message,
                            a.RecommendedAction,
                            a.Duration
                        }).ToList()
                    };

                    return JsonSerializer.Serialize(diagnosis, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "DiagnoseDeviceHealth",
                description: "对指定设备进行全面健康诊断，包括传感器健康度、维护建议、故障预测等"
            );

            // 📈 趋势分析插件  
            var trendAnalysisFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("设备ID")] string deviceId,
                        [Description("传感器类型")] string sensorType = "",
                        [Description("分析天数")] int days = 7) =>
                {
                var timeSpan = TimeSpan.FromDays(days);
                var readings = _sensorService.GetRecentReadingsForDevice(deviceId, timeSpan);

                if (!string.IsNullOrEmpty(sensorType) && Enum.TryParse<SensorType>(sensorType, out var type))
                {
                    readings = readings.Where(r => r.SensorType == type).ToList();
                }

                var trendAnalysis = readings.GroupBy(r => r.SensorId)
                    .Select(g =>
                    {
                    var values = g.OrderBy(r => r.Timestamp).Select(r => r.Value).ToArray();
                    var timestamps = g.OrderBy(r => r.Timestamp).Select(r => r.Timestamp).ToArray();

                        return new
                        {
                            SensorId = g.Key,
                            SensorName = g.First().SensorName,
                            SensorType = g.First().SensorType,
                            DataPoints = values.Length,
                            TimeRange = new
                            {
                                Start = timestamps.First(),
                                End = timestamps.Last(),
                                DurationHours = (timestamps.Last() - timestamps.First()).TotalHours
                            },
                            Statistics = new
                            {
                                Current = values.Last(),
                                Average = values.Average(),
                                Min = values.Min(),
                                Max = values.Max(),
                                Range = values.Max() - values.Min(),
                                StandardDeviation = CalculateStandardDeviation(values)
                            },
                            TrendAnalysis = new
                            {
                                Slope = CalculateLinearTrend(values),
                                ChangeRate = values.Length > 1 ? (values.Last() - values.First()) / values.First() * 100 : 0,
                                TrendDirection = DetermineTrendDirection(values),
                                Volatility = CalculateVolatility(values)
                            },
                            Patterns = new
                            {
                                HasCyclicalPattern = DetectCyclicalPattern(values, timestamps),
                                HasSeasonalPattern = DetectSeasonalPattern(values, timestamps),
                                AnomalousPoints = DetectAnomalousPoints(values).Take(5).ToList()
                            },
                            ForecastNext24Hours = ForecastNextValues(values, 24)
                        };
                    }).ToList();

                    return JsonSerializer.Serialize(trendAnalysis, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "AnalyzeTrends",
                description: "分析设备传感器数据的趋势模式，包括线性趋势、周期性模式、异常点检测和短期预测"
            );

            // 🔧 维护建议插件
            var maintenanceFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("健康度阈值，低于此值的设备会被建议维护")] double healthThreshold = 70) =>
                {
                    var devices = _sensorService.GetAllDevices();
                    var maintenanceRecommendations = new List<object>();

                    foreach (var device in devices)
                    {
                        var healthReport = _sensorService.GenerateDeviceHealthReport(device.DeviceId);
                        var predictiveResult = _sensorService.PredictDeviceFailure(device.DeviceId);

                        if (healthReport.OverallHealthScore < healthThreshold ||
                            predictiveResult.FailureProbability > 0.3 ||
                            healthReport.ActiveAlerts.Any(a => a.Level == AlarmLevel.Critical))
                        {
                            var urgencyScore = CalculateMaintenanceUrgency(healthReport, predictiveResult);

                            maintenanceRecommendations.Add(new
                            {
                                Device = new
                                {
                                    device.DeviceId,
                                    device.DeviceName,
                                    device.DeviceType,
                                    device.Location
                                },
                                UrgencyScore = urgencyScore,
                                UrgencyLevel = urgencyScore > 80 ? "紧急" : urgencyScore > 60 ? "高" : urgencyScore > 40 ? "中" : "低",
                                CurrentStatus = new
                                {
                                    HealthScore = healthReport.OverallHealthScore,
                                    Status = device.Status,
                                    OperationHours = device.OperationHours,
                                    DaysSinceLastMaintenance = (DateTime.Now - device.LastMaintenanceDate).TotalDays
                                },
                                RiskAssessment = new
                                {
                                    FailureProbability = predictiveResult.FailureProbability,
                                    PredictedFailureDate = predictiveResult.PredictedFailureDate,
                                    FailureMode = predictiveResult.FailureMode,
                                    RemainingUsefulLife = healthReport.RemainingUsefulLife
                                },
                                Recommendations = new
                                {
                                    MaintenanceActions = healthReport.MaintenanceRecommendations,
                                    PreventiveActions = predictiveResult.PreventiveActions,
                                    EstimatedDowntime = EstimateMaintenanceDowntime(device.DeviceType, urgencyScore),
                                    RecommendedTimeWindow = GetRecommendedMaintenanceWindow(urgencyScore)
                                },
                                CriticalAlerts = healthReport.ActiveAlerts.Where(a => a.Level == AlarmLevel.Critical)
                                    .Select(a => a.Message).ToList()
                            });
                        }
                    }

                    var summary = new
                    {
                        TotalDevicesAnalyzed = devices.Count,
                        DevicesRequiringMaintenance = maintenanceRecommendations.Count,
                        UrgencyDistribution = maintenanceRecommendations.Cast<dynamic>()
                            .GroupBy(r => r.UrgencyLevel)
                            .ToDictionary(g => g.Key.ToString(), g => g.Count()),
                        DeviceRecommendations = maintenanceRecommendations.OrderByDescending(r => ((dynamic)r).UrgencyScore)
                    };

                    return JsonSerializer.Serialize(summary, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "GenerateMaintenanceRecommendations",
                description: "基于设备健康状态和预测性分析，生成维护建议和优先级排序"
            );

            // 📊 系统性能报告插件
            var performanceReportFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("报告时间范围（小时）")] int hours = 24) =>
                {
                    var timeSpan = TimeSpan.FromHours(hours);
                    var stats = _sensorService.GetRealTimeStatistics();
                    var devices = _sensorService.GetAllDevices();
                    var allReadings = _sensorService.GetAllSensorReadings()
                        .Where(r => (DateTime.Now - r.Timestamp) <= timeSpan).ToList();

                    var performanceReport = new
                    {
                        ReportGenerated = DateTime.Now,
                        TimeRange = $"过去{hours}小时",

                        SystemOverall = new
                        {
                            stats.TotalDevices,
                            stats.ActiveDevices,
                            DeviceAvailability = (double)stats.ActiveDevices / stats.TotalDevices * 100,
                            stats.AverageDeviceHealth,
                            stats.TotalSensors,
                            stats.ActiveSensors,
                            SensorAvailability = (double)stats.ActiveSensors / stats.TotalSensors * 100
                        },

                        DataQuality = new
                        {
                            TotalReadings = allReadings.Count,
                            ReadingsPerHour = allReadings.Count / (double)hours,
                            DataCompleteness = CalculateDataCompleteness(allReadings, devices, timeSpan),
                            AverageLatency = CalculateAverageLatency(allReadings),
                            ErrorRate = CalculateErrorRate(allReadings)
                        },

                        AlertSummary = new
                        {
                            stats.ActiveAlertsCount,
                            stats.CriticalAlertsCount,
                            stats.WarningAlertsCount,
                            AlertsPerDevice = stats.ActiveAlertsCount / (double)Math.Max(1, stats.ActiveDevices),
                            TopAlertingDevices = _sensorService.GetActiveAlerts()
                                .GroupBy(a => a.DeviceName)
                                .OrderByDescending(g => g.Count())
                                .Take(5)
                                .Select(g => new { DeviceName = g.Key, AlertCount = g.Count() })
                                .ToList()
                        },

                        DevicePerformance = devices.Select(d => new
                        {
                            d.DeviceName,
                            d.DeviceType,
                            d.Status,
                            d.OverallHealthScore,
                            HealthTrend = CalculateHealthTrend(d.DeviceId, TimeSpan.FromDays(7)),
                            OperationalEfficiency = CalculateOperationalEfficiency(d, allReadings),
                            UptimePercentage = CalculateUptimePercentage(d, timeSpan)
                        }).OrderBy(d => d.OverallHealthScore).ToList(),

                        SensorTypeAnalysis = allReadings.GroupBy(r => r.SensorType)
                            .Select(g => new
                            {
                                SensorType = g.Key.ToString(),
                                ReadingCount = g.Count(),
                                AverageValue = g.Average(r => r.Value),
                                AnomaliesCount = g.Count(r => r.AlarmLevel != AlarmLevel.Normal),
                                AnomalyRate = g.Count(r => r.AlarmLevel != AlarmLevel.Normal) / (double)g.Count() * 100
                            }).ToList(),

                        Recommendations = GenerateSystemRecommendations(stats, devices, allReadings)
                    };

                    return JsonSerializer.Serialize(performanceReport, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "GeneratePerformanceReport",
                description: "生成系统整体性能报告，包括设备可用性、数据质量、告警统计和性能分析"
            );

            // 注册所有插件
            _kernel.ImportPluginFromFunctions("DeviceMonitoring", [deviceOverviewFunction]);
            _kernel.ImportPluginFromFunctions("SensorAnalysis", [sensorDataFunction]);
            _kernel.ImportPluginFromFunctions("AlertManagement", [alertAnalysisFunction]);
            _kernel.ImportPluginFromFunctions("HealthDiagnostics", [healthDiagnosisFunction]);
            _kernel.ImportPluginFromFunctions("TrendAnalysis", [trendAnalysisFunction]);
            _kernel.ImportPluginFromFunctions("MaintenanceManagement", [maintenanceFunction]);
            _kernel.ImportPluginFromFunctions("PerformanceReporting", [performanceReportFunction]);
        }

        // 辅助计算方法
        private static double CalculateStandardDeviation(double[] values)
        {
            if (values.Length <= 1) return 0;

            var mean = values.Average();
            var sumOfSquaredDifferences = values.Select(x => Math.Pow(x - mean, 2)).Sum();
            return Math.Sqrt(sumOfSquaredDifferences / values.Length);
        }

        private static double CalculateLinearTrend(double[] values)
        {
            if (values.Length < 2) return 0;

            var n = values.Length;
            var sumX = 0;
            var sumY = values.Sum();
            var sumXY = 0.0;
            var sumX2 = 0;

            for (int i = 0; i < n; i++)
            {
                sumX += i;
                sumXY += i * values[i];
                sumX2 += i * i;
            }

            return (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        }

        private static string DetermineTrendDirection(double[] values)
        {
            if (values.Length < 2) return "无足够数据";

            var slope = CalculateLinearTrend(values);

            if (Math.Abs(slope) < 0.001) return "稳定";
            return slope > 0 ? "上升" : "下降";
        }

        private static double CalculateVolatility(double[] values)
        {
            if (values.Length <= 1) return 0;

            var changes = new List<double>();
            for (int i = 1; i < values.Length; i++)
            {
                if (values[i - 1] != 0)
                {
                    changes.Add(Math.Abs((values[i] - values[i - 1]) / values[i - 1]));
                }
            }

            return changes.Any() ? changes.Average() * 100 : 0; // 返回百分比
        }

        private static bool DetectCyclicalPattern(double[] values, DateTime[] timestamps)
        {
            if (values.Length < 10) return false;

            // 简单的周期性检测：检查是否有重复的模式
            var periods = new[] { 60, 1440, 10080 }; // 分钟：小时、天、周

            foreach (var period in periods)
            {
                if (timestamps.Length > period * 2)
                {
                    var correlation = CalculateAutocorrelation(values, period);
                    if (correlation > 0.7) return true;
                }
            }

            return false;
        }

        private static bool DetectSeasonalPattern(double[] values, DateTime[] timestamps)
        {
            if (timestamps.Length < 24 * 7) return false; // 需要至少一周的数据

            // 检查小时级别的季节性模式
            var hourlyAverages = timestamps.Zip(values, (t, v) => new { Hour = t.Hour, Value = v })
                .GroupBy(x => x.Hour)
                .Select(g => g.Average(x => x.Value))
                .ToArray();

            var seasonalVariance = CalculateStandardDeviation(hourlyAverages);
            var totalVariance = CalculateStandardDeviation(values);

            return totalVariance > 0 && (seasonalVariance / totalVariance) > 0.3;
        }

        private static double CalculateAutocorrelation(double[] values, int lag)
        {
            if (values.Length <= lag) return 0;

            var n = values.Length - lag;
            var mean = values.Average();

            var covariance = 0.0;
            var variance = 0.0;

            for (int i = 0; i < n; i++)
            {
                covariance += (values[i] - mean) * (values[i + lag] - mean);
                variance += Math.Pow(values[i] - mean, 2);
            }

            return variance == 0 ? 0 : covariance / variance;
        }

        private static List<int> DetectAnomalousPoints(double[] values)
        {
            if (values.Length < 5) return new List<int>();

            var mean = values.Average();
            var stdDev = CalculateStandardDeviation(values);
            var threshold = 2.5 * stdDev; // 2.5σ规则

            var anomalies = new List<int>();
            for (int i = 0; i < values.Length; i++)
            {
                if (Math.Abs(values[i] - mean) > threshold)
                {
                    anomalies.Add(i);
                }
            }

            return anomalies;
        }

        private static List<double> ForecastNextValues(double[] values, int hours)
        {
            if (values.Length < 5) return new List<double> { values.LastOrDefault() };

            // 简单的线性预测
            var slope = CalculateLinearTrend(values);
            var lastValue = values.Last();
            var forecast = new List<double>();

            for (int i = 1; i <= hours; i++)
            {
                var predictedValue = lastValue + slope * i;
                forecast.Add(Math.Round(predictedValue, 2));
            }

            return forecast;
        }

        private static double CalculateMaintenanceUrgency(DeviceHealthReport healthReport, PredictiveMaintenanceResult predictive)
        {
            var urgency = 0.0;

            // 基于健康分数
            urgency += (100 - healthReport.OverallHealthScore) * 0.3;

            // 基于故障概率
            urgency += predictive.FailureProbability * 50;

            // 基于告警数量和严重程度
            var criticalAlerts = healthReport.ActiveAlerts.Count(a => a.Level == AlarmLevel.Critical);
            var warningAlerts = healthReport.ActiveAlerts.Count(a => a.Level == AlarmLevel.Warning);
            urgency += criticalAlerts * 15 + warningAlerts * 5;

            // 基于剩余使用寿命
            if (healthReport.RemainingUsefulLife < 1000) urgency += 20;
            else if (healthReport.RemainingUsefulLife < 5000) urgency += 10;

            return Math.Min(100, urgency);
        }

        private static string EstimateMaintenanceDowntime(DeviceType deviceType, double urgencyScore)
        {
            double baseHours = deviceType switch
            {
                DeviceType.Motor => 4.0,
                DeviceType.Pump => 6.0,
                DeviceType.Compressor => 8.0,
                DeviceType.Robot => 12.0,
                DeviceType.Furnace => 24.0,
                _ => 6.0
            };

            if (urgencyScore > 80)
            {
                baseHours *= 1.5; // 紧急维护可能需要更多时间
            }

            var minHours = (int)Math.Ceiling(baseHours);
            var maxHours = (int)Math.Ceiling(baseHours * 2);

            return $"{minHours}-{maxHours}小时";
        }


        private static string GetRecommendedMaintenanceWindow(double urgencyScore)
        {
            return urgencyScore switch
            {
                > 80 => "立即停机维护",
                > 60 => "24小时内安排维护",
                > 40 => "一周内安排维护",
                _ => "下个月内安排计划维护"
            };
        }

        private static double CalculateDataCompleteness(List<SensorReading> readings, List<Device> devices, TimeSpan timeSpan)
        {
            var expectedReadings = devices.SelectMany(d => d.Sensors.Where(s => s.IsActive))
                .Sum(s => timeSpan.TotalSeconds / (1.0 / s.SamplingRate));

            return expectedReadings > 0 ? readings.Count / expectedReadings * 100 : 100;
        }

        private static double CalculateAverageLatency(List<SensorReading> readings)
        {
            // 模拟延迟计算，实际应用中需要真实的网络延迟数据
            return readings.Any() ? 50 + new Random().NextDouble() * 100 : 0; // 50-150ms
        }

        private static double CalculateErrorRate(List<SensorReading> readings)
        {
            var errorReadings = readings.Count(r => r.AlarmLevel == AlarmLevel.Emergency);
            return readings.Any() ? errorReadings / (double)readings.Count * 100 : 0;
        }

        private double CalculateHealthTrend(string deviceId, TimeSpan timeSpan)
        {
            // 简化的健康趋势计算
            var device = _sensorService.GetAllDevices().FirstOrDefault(d => d.DeviceId == deviceId);
            return device?.OverallHealthScore >= 80 ? 1 : device?.OverallHealthScore >= 60 ? 0 : -1;
        }

        private static double CalculateOperationalEfficiency(Device device, List<SensorReading> readings)
        {
            var deviceReadings = readings.Where(r => r.DeviceId == device.DeviceId).ToList();
            if (!deviceReadings.Any()) return 85; // 默认效率

            var normalReadings = deviceReadings.Count(r => r.AlarmLevel == AlarmLevel.Normal);
            return normalReadings / (double)deviceReadings.Count * 100;
        }

        private static double CalculateUptimePercentage(Device device, TimeSpan timeSpan)
        {
            // 简化的正常运行时间计算
            return device.Status == DeviceStatus.Running ? 95 + new Random().NextDouble() * 5 :
                   device.Status == DeviceStatus.Idle ? 80 :
                   device.Status == DeviceStatus.Fault ? 20 : 0;
        }

        private static List<string> GenerateSystemRecommendations(SensorSystemStatistics stats, List<Device> devices, List<SensorReading> readings)
        {
            var recommendations = new List<string>();

            // 基于设备健康度
            if (stats.AverageDeviceHealth < 70)
            {
                recommendations.Add("系统整体健康度偏低，建议优先维护低健康度设备");
            }

            // 基于告警数量
            if (stats.CriticalAlertsCount > 5)
            {
                recommendations.Add($"当前有{stats.CriticalAlertsCount}个严重告警，需要立即处理");
            }

            // 基于设备可用性
            var availability = (double)stats.ActiveDevices / stats.TotalDevices;
            if (availability < 0.9)
            {
                recommendations.Add($"设备可用性为{availability:P1}，低于90%标准，需要检查离线设备");
            }

            // 基于数据质量
            var errorRate = CalculateErrorRate(readings);
            if (errorRate > 5)
            {
                recommendations.Add($"数据错误率为{errorRate:F1}%，建议检查传感器校准");
            }

            if (recommendations.Count == 0)
            {
                recommendations.Add("系统运行状态良好，继续保持现有维护策略");
            }

            return recommendations;
        }

        public async Task<string> AnalyzeAsync(string userMessage)
        {
            var systemMessage = @"你是一位资深的工业设备传感器数据分析专家，具备以下专业能力：

🏭 **设备监控专业知识**
- 工业设备类型和传感器应用
- 设备健康评估和故障诊断
- 预测性维护策略制定

📊 **数据分析能力**
- 传感器数据趋势分析和异常检测
- 统计分析和模式识别
- 多维数据关联分析

🔧 **维护管理经验**
- 设备故障模式识别
- 维护优先级排序
- 成本效益分析

⚠️ **告警管理**
- 告警根因分析
- 告警优先级评估
- 应急响应建议

请根据用户的询问，使用专业的工业术语和实用的分析建议来回答问题。回答要具体、可操作，并提供数据支撑。";

            var history = new Microsoft.SemanticKernel.ChatCompletion.ChatHistory();
            history.AddSystemMessage(systemMessage);
            history.AddUserMessage(userMessage);

            var executionSettings = new OpenAIPromptExecutionSettings
            {
                ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions,
                MaxTokens = 3000,
                Temperature = 0.1 // 保持分析的准确性和一致性
            };

            var chatService = _kernel.GetRequiredService<IChatCompletionService>();
            var response = await chatService.GetChatMessageContentAsync(
                history, executionSettings, _kernel);

            return response.Content;
        }
    }
}