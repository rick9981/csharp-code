﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAiIndustrialSensorAnalyzer
{
    public enum SensorType
    {
        Temperature,     // 温度传感器
        Pressure,        // 压力传感器
        Vibration,       // 振动传感器
        Flow,           // 流量传感器
        Speed,          // 转速传感器
        Current,        // 电流传感器
        Voltage,        // 电压传感器
        pH,             // pH值传感器
        Humidity,       // 湿度传感器
        Position,       // 位置传感器
        Force,          // 力传感器
        Torque          // 扭矩传感器
    }

    public enum DeviceType
    {
        Motor,          // 电机
        Pump,           // 泵
        Compressor,     // 压缩机
        Conveyor,       // 输送带
        Robot,          // 工业机器人
        Furnace,        // 炉子
        Tank,           // 储罐
        Valve,          // 阀门
        Generator,      // 发电机
        Transformer     // 变压器
    }

    public enum AlarmLevel
    {
        Normal,         // 正常
        Warning,        // 警告
        Critical,       // 危险
        Emergency       // 紧急
    }

    public enum DeviceStatus
    {
        Running,        // 运行中
        Idle,          // 空闲
        Maintenance,    // 维护中
        Fault,         // 故障
        Stopped        // 停止
    }

    public class SensorReading
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public DateTime Timestamp { get; set; }
        public string DeviceId { get; set; }
        public string DeviceName { get; set; }
        public DeviceType DeviceType { get; set; }
        public string SensorId { get; set; }
        public string SensorName { get; set; }
        public SensorType SensorType { get; set; }
        public double Value { get; set; }
        public string Unit { get; set; }
        public double MinValue { get; set; }
        public double MaxValue { get; set; }
        public double NormalRangeMin { get; set; }
        public double NormalRangeMax { get; set; }
        public AlarmLevel AlarmLevel { get; set; }
        public string Location { get; set; }
        public Dictionary<string, object> Metadata { get; set; } = new();
    }

    public class Device
    {
        public string DeviceId { get; set; }
        public string DeviceName { get; set; }
        public DeviceType DeviceType { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public DateTime InstallationDate { get; set; }
        public DateTime LastMaintenanceDate { get; set; }
        public DeviceStatus Status { get; set; }
        public string Location { get; set; }
        public List<Sensor> Sensors { get; set; } = new();
        public double OverallHealthScore { get; set; }
        public double OperationHours { get; set; }
        public Dictionary<string, object> Specifications { get; set; } = new();
    }

    public class Sensor
    {
        public string SensorId { get; set; }
        public string SensorName { get; set; }
        public SensorType SensorType { get; set; }
        public string Unit { get; set; }
        public double MinValue { get; set; }
        public double MaxValue { get; set; }
        public double NormalRangeMin { get; set; }
        public double NormalRangeMax { get; set; }
        public double Accuracy { get; set; }
        public double SamplingRate { get; set; } // Hz
        public DateTime CalibrationDate { get; set; }
        public bool IsActive { get; set; }
    }

    public class SensorAlert
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public DateTime Timestamp { get; set; }
        public string DeviceId { get; set; }
        public string DeviceName { get; set; }
        public string SensorId { get; set; }
        public string SensorName { get; set; }
        public SensorType SensorType { get; set; }
        public AlarmLevel Level { get; set; }
        public double CurrentValue { get; set; }
        public double ThresholdValue { get; set; }
        public string Message { get; set; }
        public string RecommendedAction { get; set; }
        public bool IsAcknowledged { get; set; }
        public bool IsResolved { get; set; }
        public TimeSpan Duration { get; set; }
    }

    public class DeviceHealthReport
    {
        public string DeviceId { get; set; }
        public string DeviceName { get; set; }
        public DateTime GeneratedTime { get; set; }
        public double OverallHealthScore { get; set; }
        public DeviceStatus Status { get; set; }
        public List<SensorHealthMetric> SensorMetrics { get; set; } = new();
        public List<string> MaintenanceRecommendations { get; set; } = new();
        public DateTime PredictedNextMaintenance { get; set; }
        public double RemainingUsefulLife { get; set; } // 剩余使用寿命（小时）
        public List<SensorAlert> ActiveAlerts { get; set; } = new();
    }

    public class SensorHealthMetric
    {
        public string SensorId { get; set; }
        public string SensorName { get; set; }
        public SensorType SensorType { get; set; }
        public double HealthScore { get; set; }
        public double AverageValue { get; set; }
        public double StandardDeviation { get; set; }
        public double TrendSlope { get; set; } // 趋势斜率
        public int AnomalyCount { get; set; }
        public DateTime LastAnomalyTime { get; set; }
    }

    public class PredictiveMaintenanceResult
    {
        public string DeviceId { get; set; }
        public string DeviceName { get; set; }
        public DateTime PredictionTime { get; set; }
        public double FailureProbability { get; set; }
        public DateTime PredictedFailureDate { get; set; }
        public string FailureMode { get; set; }
        public List<string> ContributingFactors { get; set; } = new();
        public List<string> PreventiveActions { get; set; } = new();
        public double ConfidenceLevel { get; set; }
    }
}
