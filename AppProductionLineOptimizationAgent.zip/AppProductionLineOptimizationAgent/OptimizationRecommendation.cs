﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// 优化建议模型
    /// </summary>
    public class OptimizationRecommendation
    {
        public string RecommendationId { get; set; } = Guid.NewGuid().ToString();
        public string LineId { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty; // Performance, Quality, Energy, Maintenance
        public string Priority { get; set; } = string.Empty; // High, Medium, Low
        public string Description { get; set; } = string.Empty;
        public List<string> ActionItems { get; set; } = new();
        public double ExpectedImprovement { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
