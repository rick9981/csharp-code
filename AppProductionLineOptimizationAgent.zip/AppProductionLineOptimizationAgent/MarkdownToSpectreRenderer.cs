﻿using Spectre.Console;
using Spectre.Console.Rendering;
using System.Text.RegularExpressions;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// Markdown渲染器
    /// </summary>
    public static class MarkdownToSpectreRenderer
    {
        public static Panel RenderAsPanel(string markdown, string title = "📊 分析结果")
        {
            var content = ProcessMarkdownContent(markdown);

            return new Panel(content)
            {
                Header = new PanelHeader($" [bold green]{title}[/] "),
                Border = BoxBorder.Double,
                BorderStyle = Style.Parse("green"),
                Padding = new Padding(2, 1, 2, 1)
            };
        }

        private static IRenderable ProcessMarkdownContent(string markdown)
        {
            var lines = markdown.Split('\n', StringSplitOptions.None);
            var elements = new List<IRenderable>();
            var currentSection = new List<string>();

            foreach (var line in lines)
            {
                if (IsNewSection(line))
                {
                    // 处理前一个section
                    if (currentSection.Any())
                    {
                        var sectionElement = ProcessSection(currentSection);
                        if (sectionElement != null)
                        {
                            elements.Add(sectionElement);
                        }
                        currentSection.Clear();
                    }
                }
                currentSection.Add(line);
            }

            // 处理最后一个section
            if (currentSection.Any())
            {
                var sectionElement = ProcessSection(currentSection);
                if (sectionElement != null)
                {
                    elements.Add(sectionElement);
                }
            }

            return new Rows(elements);
        }

        private static bool IsNewSection(string line)
        {
            return line.StartsWith("### ") || line.StartsWith("## ") ||
                   (line.StartsWith("#### ") && !line.Contains("立即行动"));
        }

        private static IRenderable ProcessSection(List<string> sectionLines)
        {
            if (!sectionLines.Any()) return null;

            var firstLine = sectionLines.First();
            var contentLines = sectionLines.Skip(1).Where(l => !string.IsNullOrWhiteSpace(l)).ToList();

            // 确定section类型和样式
            var (headerStyle, borderColor, icon) = DetermineSectionStyle(firstLine);

            if (!contentLines.Any())
            {
                return new Markup($"{headerStyle}{icon}{ExtractHeaderText(firstLine)}[/]");
            }

            // 处理内容
            var processedContent = ProcessSectionContent(contentLines);

            // 为重要section创建子面板
            if (ShouldCreateSubPanel(firstLine))
            {
                return new Panel(processedContent)
                {
                    Header = new PanelHeader($"{headerStyle}{icon}{ExtractHeaderText(firstLine)}[/]"),
                    Border = BoxBorder.Rounded,
                    BorderStyle = Style.Parse(borderColor),
                    Padding = new Padding(1, 0, 1, 0)
                };
            }
            else
            {
                var elements = new List<IRenderable>
                {
                    new Markup($"{headerStyle}{icon}{ExtractHeaderText(firstLine)}[/]"),
                    processedContent
                };
                return new Rows(elements);
            }
        }

        private static (string headerStyle, string borderColor, string icon) DetermineSectionStyle(string headerLine)
        {
            return headerLine switch
            {
                var h when h.Contains("实时状态") || h.Contains("概览") =>
                    ("[bold green]", "green", "📊 "),
                var h when h.Contains("历史") || h.Contains("趋势") =>
                    ("[bold blue]", "blue", "📈 "),
                var h when h.Contains("异常") || h.Contains("检测") =>
                    ("[bold red]", "red", "⚠️ "),
                var h when h.Contains("优化") || h.Contains("建议") =>
                    ("[bold yellow]", "yellow", "💡 "),
                var h when h.Contains("预期") || h.Contains("改善") =>
                    ("[bold magenta]", "magenta", "🎯 "),
                _ => ("[bold white]", "grey", "📝 ")
            };
        }

        private static string ExtractHeaderText(string headerLine)
        {
            return Regex.Replace(headerLine, @"^#{1,6}\s*", "").Trim();
        }

        private static bool ShouldCreateSubPanel(string headerLine)
        {
            return headerLine.Contains("异常检测") ||
                   headerLine.Contains("优化建议") ||
                   headerLine.Contains("预期改善");
        }

        private static IRenderable ProcessSectionContent(List<string> contentLines)
        {
            var elements = new List<IRenderable>();

            foreach (var line in contentLines)
            {
                var processed = ProcessContentLine(line.Trim());
                if (processed != null)
                {
                    elements.Add(processed);
                }
            }

            return elements.Any() ? new Rows(elements) : new Text("");
        }

        private static IRenderable ProcessContentLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line)) return null;

            // 处理键值对格式
            if (Regex.IsMatch(line, @"^-\s*\*\*.*?\*\*:\s*.*"))
            {
                var match = Regex.Match(line, @"^-\s*\*\*(.*?)\*\*:\s*(.*)");
                if (match.Success)
                {
                    var key = match.Groups[1].Value;
                    var value = match.Groups[2].Value;
                    return new Markup($"  [bold cyan]{EscapeMarkup(key)}:[/] [white]{ProcessInlineFormatting(value)}[/]");
                }
            }

            // 处理普通列表项
            if (line.StartsWith("- "))
            {
                var content = line.Substring(2);
                return new Markup($"  [dim]•[/] {ProcessInlineFormatting(content)}");
            }

            // 处理缩进列表项
            if (Regex.IsMatch(line, @"^\s*-\s+"))
            {
                var match = Regex.Match(line, @"^(\s*)-\s+(.*)");
                if (match.Success)
                {
                    var indent = match.Groups[1].Value.Length;
                    var content = match.Groups[2].Value;
                    var indentStr = new string(' ', Math.Max(0, indent + 2));
                    return new Markup($"{indentStr}[dim]◦[/] {ProcessInlineFormatting(content)}");
                }
            }

            // 处理普通段落
            return new Markup(ProcessInlineFormatting(line));
        }

        private static string ProcessInlineFormatting(string text)
        {
            // 先转义所有方括号
            text = EscapeMarkup(text);

            // 处理粗体
            text = Regex.Replace(text, @"\*\*(.*?)\*\*", "[bold]$1[/]");

            // 处理数值高亮
            text = Regex.Replace(text, @"(\d+\.?\d*%)", "[green]$1[/]");
            text = Regex.Replace(text, @"(\d+\.?\d*°C)", "[yellow]$1[/]");
            text = Regex.Replace(text, @"(\d+\.?\d*\s*[Bb]ar)", "[blue]$1[/]");

            // 处理状态指示
            text = text.Replace("🔴", "[red]🔴[/]")
                      .Replace("🟡", "[yellow]🟡[/]")
                      .Replace("🟢", "[green]🟢[/]");

            return text;
        }

        private static string EscapeMarkup(string text)
        {
            return text.Replace("[", "[[").Replace("]", "]]");
        }
    }
}