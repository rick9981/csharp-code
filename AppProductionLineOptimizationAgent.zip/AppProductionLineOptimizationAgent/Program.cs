﻿using Microsoft.SemanticKernel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.ComponentModel;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Spectre.Console;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// 主程序入口
    /// </summary>
    public class Program
    {
        /// <summary>
        /// 初始化Kernel
        /// </summary>
        static Kernel InitializeKernel()
        {
            var kernelBuilder = Kernel.CreateBuilder();
            kernelBuilder.AddOpenAIChatCompletion(
                modelId: "deepseek-chat",
                apiKey: Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY") ?? "sk-xxxx",
                endpoint: new Uri("https://api.deepseek.com/v1")
            );
            return kernelBuilder.Build();
        }

        /// <summary>
        /// 配置服务
        /// </summary>
        static void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(builder =>
            {
                builder.AddConsole();
                builder.SetMinimumLevel(LogLevel.Information);
            });

            services.AddSingleton<IProductionDataService, ProductionDataService>();
            services.AddSingleton<ProductionAnalysisPlugin>();
            services.AddSingleton<ProductionOptimizationAgent>();
        }

        static async Task Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // 显示美化的启动界面
            ShowStartupBanner();

            // 配置服务容器
            var services = new ServiceCollection();
            ConfigureServices(services);
            var serviceProvider = services.BuildServiceProvider();

            var logger = serviceProvider.GetRequiredService<ILogger<Program>>();

            // 显示初始化状态
            AnsiConsole.Status()
                .Spinner(Spinner.Known.Dots)
                .SpinnerStyle(Style.Parse("green bold"))
                .Start("🔧 系统初始化中...", ctx =>
                {
                    logger.LogInformation("🏭 生产线流程智能优化Agent 启动中...");
                });

            try
            {
                // 初始化Kernel
                var kernel = InitializeKernel();

                // 注册生产分析插件
                var analysisPlugin = serviceProvider.GetRequiredService<ProductionAnalysisPlugin>();
                kernel.Plugins.AddFromObject(analysisPlugin, "ProductionAnalysis");

                // 添加时间插件用于处理时间相关查询
                kernel.Plugins.AddFromType<CustomTimePlugin>("Time");

                // 创建优化Agent
                var agent = new ProductionOptimizationAgent(kernel,
                    serviceProvider.GetRequiredService<ILogger<ProductionOptimizationAgent>>());

                logger.LogInformation("✅ 系统初始化完成！");
                AnsiConsole.MarkupLine("[green bold]✅ 系统初始化完成！[/]");

                // 交互式命令行界面
                await RunInteractiveMode(agent, logger);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "❌ 系统启动失败");
                AnsiConsole.WriteException(ex, ExceptionFormats.ShortenEverything);
            }

            logger.LogInformation("🔄 程序结束");
            AnsiConsole.MarkupLine("[yellow]👋 程序结束，感谢使用！[/]");
        }

        /// <summary>
        /// 显示启动横幅
        /// </summary>
        static void ShowStartupBanner()
        {
            var rule = new Rule("[bold blue]🏭 生产线流程智能优化Agent[/]");
            rule.Justification = Justify.Center;
            AnsiConsole.Write(rule);

            var panel = new Panel(
                new Markup("[bold]✨ 功能特性:[/]\n" +
                          "• [green]实时数据监控与分析[/]\n" +
                          "• [yellow]智能异常检测与诊断[/]\n" +
                          "• [blue]生产优化建议生成[/]\n" +
                          "• [magenta]详细生产报告输出[/]"))
            {
                Header = new PanelHeader(" [bold cyan]系统介绍[/] "),
                Border = BoxBorder.Rounded,
                BorderStyle = Style.Parse("cyan")
            };
            AnsiConsole.Write(panel);
            AnsiConsole.WriteLine();
        }

        /// <summary>
        /// 交互式模式
        /// </summary>
        static async Task RunInteractiveMode(ProductionOptimizationAgent agent, ILogger logger)
        {
            ShowExampleQueries();

            while (true)
            {
                var input = AnsiConsole.Ask<string>("\n[bold cyan]🤖 请输入您的查询:[/]");

                if (string.IsNullOrWhiteSpace(input))
                    continue;

                if (input.ToLower().Trim() == "exit")
                {
                    AnsiConsole.MarkupLine("[yellow]👋 再见！[/]");
                    break;
                }

                if (input.ToLower().Trim() == "help")
                {
                    ShowExampleQueries();
                    continue;
                }

                try
                {
                    var startTime = DateTime.Now;
                    string response = "";

                    // 显示分析进度
                    await AnsiConsole.Status()
                        .Spinner(Spinner.Known.BouncingBar)
                        .SpinnerStyle(Style.Parse("green bold"))
                        .StartAsync("[green]🔄 AI正在分析中，请稍候...[/]", async ctx =>
                        {
                            response = await agent.OptimizeProductionLineAsync(input);
                        });

                    var duration = DateTime.Now - startTime;

                    // 使用Markdown渲染器显示结果
                    DisplayMarkdownResult(response, duration);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "处理查询失败");

                    var errorPanel = new Panel($"[red]{ex.Message}[/]")
                    {
                        Header = new PanelHeader(" [bold red]❌ 处理失败[/] "),
                        Border = BoxBorder.Heavy,
                        BorderStyle = Style.Parse("red")
                    };
                    AnsiConsole.Write(errorPanel);
                }
            }
        }

        /// <summary>
        /// 显示示例查询
        /// </summary>
        static void ShowExampleQueries()
        {
            var table = new Table();
            table.Border = TableBorder.Rounded;
            table.BorderStyle = Style.Parse("grey");
            table.AddColumn(new TableColumn("[bold yellow]💡 示例查询[/]").Centered());

            var examples = new[]
            {
                "分析生产线A1的当前状态",
                "检查所有生产线的实时数据",
                "为生产线B2生成优化建议",
                "分析最近24小时的生产异常",
                "生成生产线C1的详细报告"
            };

            foreach (var example in examples)
            {
                table.AddRow($"[cyan]• {example}[/]");
            }

            AnsiConsole.Write(table);
            AnsiConsole.MarkupLine("\n[dim]💡 输入 'help' 查看帮助，输入 'exit' 退出程序[/]");
        }

        /// <summary>
        /// 使用Markdown渲染器显示分析结果
        /// </summary>
        static void DisplayMarkdownResult(string response, TimeSpan duration)
        {
            try
            {
                // 使用自定义Markdown渲染器
                var renderedContent = MarkdownToSpectreRenderer.RenderAsPanel(response);

                // 创建结果面板
                var resultPanel = new Panel(renderedContent)
                {
                    Header = new PanelHeader(" [bold green]📊 分析结果[/] "),
                    Border = BoxBorder.Double,
                    BorderStyle = Style.Parse("green"),
                    Padding = new Padding(2, 1, 2, 1)
                };

                AnsiConsole.Write(resultPanel);

                // 显示性能信息
                DisplayPerformanceInfo(duration);
            }
            catch (Exception ex)
            {
                // 如果Markdown解析失败，回退到原始显示
                AnsiConsole.MarkupLine("[yellow]⚠️ Markdown解析失败，使用原始格式显示[/]");

                var fallbackPanel = new Panel(new Text(response))
                {
                    Header = new PanelHeader(" [bold green]📊 分析结果[/] "),
                    Border = BoxBorder.Double,
                    BorderStyle = Style.Parse("green")
                };

                AnsiConsole.Write(fallbackPanel);
                DisplayPerformanceInfo(duration);

                AnsiConsole.MarkupLine($"[dim]解析错误: {ex.Message}[/]");
            }
        }

        /// <summary>
        /// 显示性能信息
        /// </summary>
        static void DisplayPerformanceInfo(TimeSpan duration)
        {
            var perfTable = new Table();
            perfTable.Border = TableBorder.None;
            perfTable.HideHeaders();
            perfTable.AddColumn("", col => col.NoWrap = true);
            perfTable.AddColumn("");

            perfTable.AddRow("[bold blue]⏱️ 分析耗时:[/]", $"[green]{duration.TotalSeconds:F2} 秒[/]");
            perfTable.AddRow("[bold blue]📅 完成时间:[/]", $"[yellow]{DateTime.Now:yyyy-MM-dd HH:mm:ss}[/]");
            perfTable.AddRow("[bold blue]🔄 状态:[/]", "[green]✅ 完成[/]");

            AnsiConsole.Write(perfTable);

            // 分隔线
            AnsiConsole.Write(new Rule().RuleStyle("grey dim"));
        }
    }
}