﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Microsoft.SemanticKernel;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// 主要的生产线优化Agent
    /// </summary>
    public class ProductionOptimizationAgent
    {
        private readonly Kernel _kernel;
        private readonly ILogger<ProductionOptimizationAgent> _logger;

        public ProductionOptimizationAgent(Kernel kernel, ILogger<ProductionOptimizationAgent> logger)
        {
            _kernel = kernel;
            _logger = logger;
        }

        /// <summary>
        /// 使用自动函数调用执行分析
        /// </summary>
        public async Task<string> OptimizeProductionLineAsync(string query)
        {
            try
            {
                _logger.LogInformation("🔍 开始执行生产线优化分析: {Query}", query);

                // 创建明确的提示，指导AI使用函数(这里很重要)
                var prompt = $@"
你是一个专业的生产线智能优化专家。用户查询: {query}

请按以下步骤操作：
1. 如果用户询问实时数据或当前状态，请调用 ProductionAnalysis-GetRealTimeProductionDataAsync 函数
2. 如果用户询问历史数据或趋势分析，请调用 ProductionAnalysis-GetHistoricalProductionDataAsync 函数，指定生产线ID和时间范围
3. 如果用户询问异常分析或优化建议，请调用 ProductionAnalysis-AnalyzeProductionAnomaliesAsync 函数
4. 分析获取的数据，提供专业的优化建议

现在开始分析用户的查询并调用相应的函数获取数据。
";

                // 配置执行设置，启用自动函数调用
                var executionSettings = new OpenAIPromptExecutionSettings
                {
                    ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions,
                    MaxTokens = 4000,
                    Temperature = 0.1 //这里保持低温度以获得更确定的响应
                };

                // 执行带函数调用的推理
                var result = await _kernel.InvokePromptAsync(prompt, new KernelArguments(executionSettings));
                var response = result.ToString();

                _logger.LogInformation("✅ 生产线优化分析完成，响应长度: {Length}", response?.Length ?? 0);
                return response ?? "未能生成优化建议";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ 执行生产线优化失败: Query={Query}", query);
                return $"优化分析失败: {ex.Message}";
            }
        }

        /// <summary>
        /// 生成详细报告
        /// </summary>
        public async Task<string> GenerateProductionReportAsync(string lineId, int hours = 24)
        {
            try
            {
                var prompt = $@"
请为生产线 {lineId} 生成详细的生产报告，时间范围为最近 {hours} 小时。

步骤：
1. 首先调用 ProductionAnalysis-GetHistoricalProductionDataAsync 获取历史数据，参数: lineId='{lineId}', hours={hours}
2. 然后调用 ProductionAnalysis-AnalyzeProductionAnomaliesAsync 进行异常分析，参数: lineId='{lineId}'
3. 基于获取的数据生成专业报告

报告应包含：执行摘要、KPI分析、问题诊断、改进建议等。
";

                var executionSettings = new OpenAIPromptExecutionSettings
                {
                    ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions,
                    MaxTokens = 5000,
                    Temperature = 0.1
                };

                var result = await _kernel.InvokePromptAsync(prompt, new KernelArguments(executionSettings));
                return result.ToString() ?? "报告生成失败";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ 生成生产报告失败: LineId={LineId}", lineId);
                return $"报告生成失败: {ex.Message}";
            }
        }
    }
}
