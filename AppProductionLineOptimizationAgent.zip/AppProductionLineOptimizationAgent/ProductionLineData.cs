﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// 生产线数据模型
    /// </summary>
    public class ProductionLineData
    {
        public string LineId { get; set; } = string.Empty;
        public string LineName { get; set; } = string.Empty;
        public double Efficiency { get; set; }
        public double Temperature { get; set; }
        public double Pressure { get; set; }
        public double Speed { get; set; }
        public int DefectCount { get; set; }
        public DateTime Timestamp { get; set; }
        public Dictionary<string, double> AdditionalMetrics { get; set; } = new();
    }
}
