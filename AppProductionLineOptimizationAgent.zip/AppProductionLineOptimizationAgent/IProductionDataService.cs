﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// 生产线数据服务
    /// </summary>
    public interface IProductionDataService
    {
        Task<List<ProductionLineData>> GetProductionDataAsync(string lineId, TimeSpan timeRange);
        Task<List<ProductionLineData>> GetRealTimeDataAsync();
        Task<bool> SaveOptimizationRecommendationAsync(OptimizationRecommendation recommendation);
    }
}
