﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>
    /// 生产线分析插件
    /// </summary>
    public class ProductionAnalysisPlugin
    {
        private readonly IProductionDataService _dataService;
        private readonly ILogger<ProductionAnalysisPlugin> _logger;

        public ProductionAnalysisPlugin(IProductionDataService dataService, ILogger<ProductionAnalysisPlugin> logger)
        {
            _dataService = dataService;
            _logger = logger;
        }

        [KernelFunction]
        [Description("获取生产线的实时数据")]
        public async Task<string> GetRealTimeProductionDataAsync()
        {
            try
            {
                var data = await _dataService.GetRealTimeDataAsync();
                var result = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                _logger.LogInformation("获取了 {Count} 条实时生产数据", data.Count);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取实时生产数据失败");
                return $"错误: {ex.Message}";
            }
        }

        [KernelFunction]
        [Description("获取指定生产线的历史数据")]
        public async Task<string> GetHistoricalProductionDataAsync(
            [Description("生产线ID")] string lineId,
            [Description("时间范围(小时)")] int hours = 24)
        {
            try
            {
                var timeRange = TimeSpan.FromHours(hours);
                var data = await _dataService.GetProductionDataAsync(lineId, timeRange);

                // 计算统计信息
                var avgEfficiency = data.Average(d => d.Efficiency);
                var totalDefects = data.Sum(d => d.DefectCount);
                var avgTemperature = data.Average(d => d.Temperature);

                var summary = new
                {
                    LineId = lineId,
                    DataPoints = data.Count,
                    TimeRange = $"{hours} hours",
                    AverageEfficiency = Math.Round(avgEfficiency, 2),
                    TotalDefects = totalDefects,
                    AverageTemperature = Math.Round(avgTemperature, 2),
                    Data = data.Take(10) // 只返回最近10条详细数据
                };

                return JsonSerializer.Serialize(summary, new JsonSerializerOptions { WriteIndented = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "获取历史生产数据失败: LineId={LineId}, Hours={Hours}", lineId, hours);
                return $"错误: {ex.Message}";
            }
        }

        [KernelFunction]
        [Description("分析生产线异常并提供优化建议")]
        public async Task<string> AnalyzeProductionAnomaliesAsync(
            [Description("生产线ID")] string lineId)
        {
            try
            {
                var data = await _dataService.GetProductionDataAsync(lineId, TimeSpan.FromHours(24));
                var anomalies = new List<string>();
                var recommendations = new List<OptimizationRecommendation>();

                // 效率分析
                var avgEfficiency = data.Average(d => d.Efficiency);
                if (avgEfficiency < 85)
                {
                    anomalies.Add($"效率过低: {avgEfficiency:F2}% (标准: >85%)");
                    recommendations.Add(new OptimizationRecommendation
                    {
                        LineId = lineId,
                        Category = "Performance",
                        Priority = "High",
                        Description = "生产线效率低于标准阈值",
                        ActionItems = new List<string>
                        {
                            "检查设备运行状态",
                            "优化工艺参数",
                            "培训操作人员",
                            "检查原材料质量"
                        },
                        ExpectedImprovement = 10.0
                    });
                }

                // 温度分析
                var avgTemp = data.Average(d => d.Temperature);
                var tempVariance = data.Select(d => Math.Pow(d.Temperature - avgTemp, 2)).Average();
                if (tempVariance > 25)
                {
                    anomalies.Add($"温度波动过大: 方差={tempVariance:F2}");
                    recommendations.Add(new OptimizationRecommendation
                    {
                        LineId = lineId,
                        Category = "Quality",
                        Priority = "Medium",
                        Description = "温度控制不稳定，可能影响产品质量",
                        ActionItems = new List<string>
                        {
                            "校准温度传感器",
                            "检查加热系统",
                            "优化温控PID参数"
                        },
                        ExpectedImprovement = 5.0
                    });
                }

                // 缺陷分析
                var totalDefects = data.Sum(d => d.DefectCount);
                var defectRate = (double)totalDefects / data.Count;
                if (defectRate > 2.0)
                {
                    anomalies.Add($"缺陷率过高: {defectRate:F2} 缺陷/小时");
                    recommendations.Add(new OptimizationRecommendation
                    {
                        LineId = lineId,
                        Category = "Quality",
                        Priority = "High",
                        Description = "产品缺陷率超出可接受范围",
                        ActionItems = new List<string>
                        {
                            "分析缺陷根本原因",
                            "加强质量控制检查",
                            "优化工艺流程",
                            "更新设备维护计划"
                        },
                        ExpectedImprovement = 15.0
                    });
                }

                // 保存建议到数据库
                foreach (var recommendation in recommendations)
                {
                    await _dataService.SaveOptimizationRecommendationAsync(recommendation);
                }

                var result = new
                {
                    LineId = lineId,
                    AnalysisTime = DateTime.UtcNow,
                    AnomaliesFound = anomalies.Count,
                    Anomalies = anomalies,
                    RecommendationsGenerated = recommendations.Count,
                    Recommendations = recommendations
                };

                return JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "分析生产线异常失败: LineId={LineId}", lineId);
                return $"错误: {ex.Message}";
            }
        }
    }
}
