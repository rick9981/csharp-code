﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;

namespace AppProductionLineOptimizationAgent
{
    /// <summary>  
    /// 自定义时间插件  
    /// </summary>  
    public class CustomTimePlugin
    {
        [KernelFunction]
        [Description("获取当前日期和时间")]
        public string GetCurrentDateTime()
        {
            return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        [KernelFunction]
        [Description("获取当前UTC时间")]
        public string GetCurrentUtcDateTime()
        {
            return DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC");
        }

        [KernelFunction]
        [Description("计算两个日期之间的时间差")]
        public string CalculateTimeDifference(
            [Description("开始时间 (格式: yyyy-MM-dd HH:mm:ss)")] string startTime,
            [Description("结束时间 (格式: yyyy-MM-dd HH:mm:ss)")] string endTime)
        {
            try
            {
                if (DateTime.TryParse(startTime, out var start) && DateTime.TryParse(endTime, out var end))
                {
                    var difference = end - start;
                    return $"时间差: {difference.TotalHours:F2} 小时 ({difference.TotalMinutes:F0} 分钟)";
                }
                return "日期格式错误";
            }
            catch
            {
                return "计算时间差失败";
            }
        }

        [KernelFunction]
        [Description("获取指定天数前的日期")]
        public string GetDateDaysAgo([Description("天数")] int days)
        {
            return DateTime.Now.AddDays(-days).ToString("yyyy-MM-dd");
        }
    }
}
