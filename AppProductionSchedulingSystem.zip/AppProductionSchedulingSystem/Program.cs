﻿
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.ComponentModel;
using System.Text.Json;

namespace AppProductionSchedulingSystem
{
    // 主程序入口
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            var host = Host.CreateDefaultBuilder(args)
                .ConfigureServices((context, services) =>
                {
                    // 注册服务
                    services.AddSingleton<IProductionDataService, ProductionDataService>();
                    services.AddSingleton<ISchedulingEngine, SchedulingEngine>();
                    services.AddSingleton<ProductionAnalysisPlugin>();
                    services.AddSingleton<ProductionScheduler>();
                    services.AddLogging();

                    // 配置Semantic Kernel
                    var kernelBuilder = Kernel.CreateBuilder();
                    kernelBuilder.AddOpenAIChatCompletion(
                        modelId: "deepseek-chat",
                        apiKey: Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY") ?? "sk-xxxx",
                        endpoint: new Uri("https://api.deepseek.com/v1")
                    );

                    var kernel = kernelBuilder.Build();
                    services.AddSingleton(kernel);
                })
                .Build();

            var scheduler = host.Services.GetRequiredService<ProductionScheduler>();
            await scheduler.RunSchedulingSystemAsync();
        }
    }

    // 核心数据模型
    public class ProductionOrder
    {
        public string OrderId { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public DateTime DueDate { get; set; }
        public Priority Priority { get; set; }
        public int EstimatedDuration { get; set; } // 预估生产时间(小时)
        public List<string> RequiredMachines { get; set; } = new();
        public List<string> RequiredSkills { get; set; } = new();
        public OrderStatus Status { get; set; } = OrderStatus.Pending;
    }

    public class ProductionLine
    {
        public string LineId { get; set; } = string.Empty;
        public string LineName { get; set; } = string.Empty;
        public List<Machine> Machines { get; set; } = new();
        public List<Worker> Workers { get; set; } = new();
        public double Efficiency { get; set; } = 100.0;
        public LineStatus Status { get; set; } = LineStatus.Available;
        public List<ScheduledTask> ScheduledTasks { get; set; } = new();
    }

    public class Machine
    {
        public string MachineId { get; set; } = string.Empty;
        public string MachineName { get; set; } = string.Empty;
        public MachineType Type { get; set; }
        public MachineStatus Status { get; set; } = MachineStatus.Available;
        public DateTime NextMaintenanceDate { get; set; }
        public double Efficiency { get; set; } = 100.0;
        public List<string> Capabilities { get; set; } = new();
    }

    public class Worker
    {
        public string WorkerId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public List<string> Skills { get; set; } = new();
        public WorkerStatus Status { get; set; } = WorkerStatus.Available;
        public DateTime ShiftStart { get; set; }
        public DateTime ShiftEnd { get; set; }
    }

    public class ScheduledTask
    {
        public string TaskId { get; set; } = string.Empty;
        public string OrderId { get; set; } = string.Empty;
        public string LineId { get; set; } = string.Empty;
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public TaskStatus Status { get; set; } = TaskStatus.Scheduled;
        public List<string> AssignedMachines { get; set; } = new();
        public List<string> AssignedWorkers { get; set; } = new();
    }

    public class OptimizationRecommendation
    {
        public string LineId { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Priority { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public List<string> ActionItems { get; set; } = new();
        public double ExpectedImprovement { get; set; }
    }

    public class ProductionData
    {
        public string LineId { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
        public double Efficiency { get; set; }
        public int ProductionCount { get; set; }
        public int DefectCount { get; set; }
        public double DowntimeMinutes { get; set; }
    }

    // 枚举类型
    public enum Priority { Low = 1, Medium = 2, High = 3, Critical = 4 }
    public enum OrderStatus { Pending, Scheduled, InProgress, Completed, Cancelled }
    public enum LineStatus { Available, Busy, Maintenance, Offline }
    public enum MachineStatus { Available, Busy, Maintenance, Broken }
    public enum WorkerStatus { Available, Busy, Break, Absent }
    public enum TaskStatus { Scheduled, InProgress, Completed, Cancelled }
    public enum MachineType { Assembly, Packaging, Testing, Quality }

    // 接口定义
    public interface IProductionDataService
    {
        Task<List<ProductionData>> GetProductionDataAsync(string lineId, TimeSpan timeRange);
        Task<List<ProductionOrder>> GetPendingOrdersAsync();
        Task<List<ProductionLine>> GetProductionLinesAsync();
        Task<bool> UpdateOrderStatusAsync(string orderId, OrderStatus status);
        Task<bool> SaveScheduledTaskAsync(ScheduledTask task);
    }

    public interface ISchedulingEngine
    {
        Task<List<ScheduledTask>> GenerateScheduleAsync(List<ProductionOrder> orders, List<ProductionLine> lines);
        Task<double> CalculateScheduleEfficiencyAsync(List<ScheduledTask> tasks);
        Task<List<OptimizationRecommendation>> OptimizeScheduleAsync(List<ScheduledTask> currentSchedule);
    }

    // 生产数据服务实现
    public class ProductionDataService : IProductionDataService
    {
        private readonly ILogger<ProductionDataService> _logger;

        public ProductionDataService(ILogger<ProductionDataService> logger)
        {
            _logger = logger;
        }

        public async Task<List<ProductionData>> GetProductionDataAsync(string lineId, TimeSpan timeRange)
        {
            // 模拟数据获取 - 实际项目中连接数据库
            await Task.Delay(100);
            var data = new List<ProductionData>();
            var endTime = DateTime.Now;
            var startTime = endTime - timeRange;

            var random = new Random();
            for (var time = startTime; time <= endTime; time = time.AddHours(1))
            {
                // 模拟一些有问题的数据来触发AI分析
                var efficiency = lineId == "LINE001" ? 75 + random.NextDouble() * 15 : 85 + random.NextDouble() * 10; // LINE001效率较低
                var productionCount = random.Next(50, 200);
                var defectCount = lineId == "LINE002" ? random.Next(5, 15) : random.Next(0, 5); // LINE002质量问题
                var downtime = lineId == "LINE001" ? random.NextDouble() * 45 + 30 : random.NextDouble() * 30; // LINE001停机时间长

                data.Add(new ProductionData
                {
                    LineId = lineId,
                    Timestamp = time,
                    Efficiency = efficiency,
                    ProductionCount = productionCount,
                    DefectCount = defectCount,
                    DowntimeMinutes = downtime
                });
            }

            return data;
        }

        public async Task<List<ProductionOrder>> GetPendingOrdersAsync()
        {
            await Task.Delay(50);
            return new List<ProductionOrder>
            {
                new ProductionOrder
                {
                    OrderId = "ORD001",
                    ProductName = "智能手机外壳",
                    Quantity = 1000,
                    DueDate = DateTime.Now.AddDays(3),
                    Priority = Priority.High,
                    EstimatedDuration = 8,
                    RequiredMachines = new List<string> { "Assembly", "Testing" },
                    RequiredSkills = new List<string> { "装配", "质检" }
                },
                new ProductionOrder
                {
                    OrderId = "ORD002",
                    ProductName = "电子显示屏",
                    Quantity = 500,
                    DueDate = DateTime.Now.AddDays(5),
                    Priority = Priority.Medium,
                    EstimatedDuration = 12,
                    RequiredMachines = new List<string> { "Assembly", "Testing", "Packaging" },
                    RequiredSkills = new List<string> { "装配", "测试", "包装" }
                },
                new ProductionOrder
                {
                    OrderId = "ORD003",
                    ProductName = "电路板组件",
                    Quantity = 2000,
                    DueDate = DateTime.Now.AddDays(2),
                    Priority = Priority.Critical,
                    EstimatedDuration = 6,
                    RequiredMachines = new List<string> { "Assembly", "Quality" },
                    RequiredSkills = new List<string> { "SMT操作", "质检" }
                },
                new ProductionOrder
                {
                    OrderId = "ORD004",
                    ProductName = "传感器模块",
                    Quantity = 800,
                    DueDate = DateTime.Now.AddDays(4),
                    Priority = Priority.High,
                    EstimatedDuration = 10,
                    RequiredMachines = new List<string> { "Assembly", "Testing" },
                    RequiredSkills = new List<string> { "装配", "测试" }
                }
            };
        }

        public async Task<List<ProductionLine>> GetProductionLinesAsync()
        {
            await Task.Delay(50);
            return new List<ProductionLine>
            {
                new ProductionLine
                {
                    LineId = "LINE001",
                    LineName = "智能装配线A",
                    Efficiency = 95.0,
                    Status = LineStatus.Available,
                    Machines = new List<Machine>
                    {
                        new Machine { MachineId = "M001", MachineName = "装配机A1", Type = MachineType.Assembly, Status = MachineStatus.Available, Efficiency = 98.0 },
                        new Machine { MachineId = "M002", MachineName = "测试机A1", Type = MachineType.Testing, Status = MachineStatus.Available, Efficiency = 92.0 },
                        new Machine { MachineId = "M005", MachineName = "包装机A1", Type = MachineType.Packaging, Status = MachineStatus.Available, Efficiency = 90.0 }
                    },
                    Workers = new List<Worker>
                    {
                        new Worker { WorkerId = "W001", Name = "张师傅", Skills = new List<string> { "装配", "质检" }, Status = WorkerStatus.Available },
                        new Worker { WorkerId = "W002", Name = "李工", Skills = new List<string> { "测试", "维修", "包装" }, Status = WorkerStatus.Available }
                    }
                },
                new ProductionLine
                {
                    LineId = "LINE002",
                    LineName = "精密加工线B",
                    Efficiency = 87.0,
                    Status = LineStatus.Available,
                    Machines = new List<Machine>
                    {
                        new Machine { MachineId = "M003", MachineName = "CNC加工中心", Type = MachineType.Assembly, Status = MachineStatus.Available, Efficiency = 89.0 },
                        new Machine { MachineId = "M004", MachineName = "质量检测设备", Type = MachineType.Quality, Status = MachineStatus.Available, Efficiency = 96.0 },
                        new Machine { MachineId = "M006", MachineName = "测试台B1", Type = MachineType.Testing, Status = MachineStatus.Available, Efficiency = 94.0 }
                    },
                    Workers = new List<Worker>
                    {
                        new Worker { WorkerId = "W003", Name = "王师傅", Skills = new List<string> { "CNC操作", "编程", "SMT操作" }, Status = WorkerStatus.Available },
                        new Worker { WorkerId = "W004", Name = "赵工", Skills = new List<string> { "质检", "包装", "测试" }, Status = WorkerStatus.Available }
                    }
                }
            };
        }

        public async Task<bool> UpdateOrderStatusAsync(string orderId, OrderStatus status)
        {
            await Task.Delay(50);
            _logger.LogInformation($"订单 {orderId} 状态更新为 {status}");
            return true;
        }

        public async Task<bool> SaveScheduledTaskAsync(ScheduledTask task)
        {
            await Task.Delay(50);
            _logger.LogInformation($"保存排程任务: {task.TaskId}，订单: {task.OrderId}，生产线: {task.LineId}");
            return true;
        }
    }

    // 排程引擎实现
    public class SchedulingEngine : ISchedulingEngine
    {
        private readonly ILogger<SchedulingEngine> _logger;

        public SchedulingEngine(ILogger<SchedulingEngine> logger)
        {
            _logger = logger;
        }

        public async Task<List<ScheduledTask>> GenerateScheduleAsync(List<ProductionOrder> orders, List<ProductionLine> lines)
        {
            await Task.Delay(100);
            var scheduledTasks = new List<ScheduledTask>();

            // 按优先级和交期排序订单
            var sortedOrders = orders
                .OrderByDescending(o => (int)o.Priority)
                .ThenBy(o => o.DueDate)
                .ToList();

            var currentTime = DateTime.Now.Date.AddHours(8); // 从早上8点开始

            foreach (var order in sortedOrders)
            {
                var bestLine = FindBestProductionLine(order, lines);
                if (bestLine != null)
                {
                    var task = new ScheduledTask
                    {
                        TaskId = $"TASK_{Guid.NewGuid().ToString("N")[..8]}",
                        OrderId = order.OrderId,
                        LineId = bestLine.LineId,
                        StartTime = GetNextAvailableTime(bestLine, currentTime),
                        AssignedMachines = bestLine.Machines.Where(m => order.RequiredMachines.Contains(m.Type.ToString())).Select(m => m.MachineId).ToList(),
                        AssignedWorkers = bestLine.Workers.Where(w => w.Skills.Intersect(order.RequiredSkills).Any()).Select(w => w.WorkerId).ToList()
                    };

                    task.EndTime = task.StartTime.AddHours(order.EstimatedDuration);
                    scheduledTasks.Add(task);

                    // 更新生产线状态
                    bestLine.ScheduledTasks.Add(task);

                    _logger.LogInformation($"订单 {order.OrderId} ({order.ProductName}) 已排程到生产线 {bestLine.LineName}，预计 {task.StartTime:MM-dd HH:mm} 开始生产");
                }
                else
                {
                    _logger.LogWarning($"订单 {order.OrderId} ({order.ProductName}) 无法找到合适的生产线");
                }
            }

            return scheduledTasks;
        }

        public async Task<double> CalculateScheduleEfficiencyAsync(List<ScheduledTask> tasks)
        {
            await Task.Delay(50);
            if (tasks.Count == 0) return 0;

            var totalDuration = tasks.Sum(t => (t.EndTime - t.StartTime).TotalHours);
            var timeSpan = tasks.Max(t => t.EndTime) - tasks.Min(t => t.StartTime);
            var efficiency = totalDuration / timeSpan.TotalHours * 100;

            return Math.Min(efficiency, 100);
        }

        public async Task<List<OptimizationRecommendation>> OptimizeScheduleAsync(List<ScheduledTask> currentSchedule)
        {
            await Task.Delay(100);
            var recommendations = new List<OptimizationRecommendation>();

            // 分析任务间隙
            var gaps = AnalyzeTaskGaps(currentSchedule);
            if (gaps.Any(g => g.TotalHours > 2))
            {
                recommendations.Add(new OptimizationRecommendation
                {
                    Category = "Timeline",
                    Priority = "Medium",
                    Description = "发现较大时间间隙，可考虑调整任务顺序",
                    ActionItems = new List<string> { "重新排序任务", "考虑并行生产", "填补时间空隙" },
                    ExpectedImprovement = 15.0
                });
            }

            // 分析资源利用率
            var resourceUtilization = AnalyzeResourceUtilization(currentSchedule);
            if (resourceUtilization < 70)
            {
                recommendations.Add(new OptimizationRecommendation
                {
                    Category = "Resource",
                    Priority = "High",
                    Description = $"资源利用率较低 ({resourceUtilization:F1}%)",
                    ActionItems = new List<string> { "增加并行任务", "优化设备分配", "调整班次安排" },
                    ExpectedImprovement = 25.0
                });
            }

            // 分析交期风险
            var deliveryRisks = AnalyzeDeliveryRisks(currentSchedule);
            if (deliveryRisks.Count > 0)
            {
                recommendations.Add(new OptimizationRecommendation
                {
                    Category = "Delivery",
                    Priority = "Critical",
                    Description = $"发现 {deliveryRisks.Count} 个交期风险任务",
                    ActionItems = new List<string> { "优先排程紧急订单", "增加加班时间", "考虑外包生产" },
                    ExpectedImprovement = 20.0
                });
            }

            return recommendations;
        }

        private ProductionLine? FindBestProductionLine(ProductionOrder order, List<ProductionLine> lines)
        {
            return lines
                .Where(line => line.Status == LineStatus.Available)
                .Where(line => HasRequiredCapabilities(line, order))
                .OrderByDescending(line => CalculateLineScore(line, order))
                .FirstOrDefault();
        }

        private bool HasRequiredCapabilities(ProductionLine line, ProductionOrder order)
        {
            var availableMachineTypes = line.Machines.Where(m => m.Status == MachineStatus.Available).Select(m => m.Type.ToString()).ToList();
            var availableSkills = line.Workers.Where(w => w.Status == WorkerStatus.Available).SelectMany(w => w.Skills).ToList();

            return order.RequiredMachines.All(rm => availableMachineTypes.Contains(rm)) &&
                   order.RequiredSkills.All(rs => availableSkills.Contains(rs));
        }

        private double CalculateLineScore(ProductionLine line, ProductionOrder order)
        {
            // 综合评分：生产线效率 + 技能匹配度 + 设备利用率
            var efficiencyScore = line.Efficiency;
            var skillMatchScore = CalculateSkillMatchScore(line.Workers, order.RequiredSkills);
            var machineMatchScore = CalculateMachineMatchScore(line.Machines, order.RequiredMachines);

            return efficiencyScore * 0.4 + skillMatchScore * 0.3 + machineMatchScore * 0.3;
        }

        private double CalculateSkillMatchScore(List<Worker> workers, List<string> requiredSkills)
        {
            if (!requiredSkills.Any()) return 100;

            var availableSkills = workers.SelectMany(w => w.Skills).Distinct().ToList();
            var matchCount = requiredSkills.Count(rs => availableSkills.Contains(rs));

            return (double)matchCount / requiredSkills.Count * 100;
        }

        private double CalculateMachineMatchScore(List<Machine> machines, List<string> requiredMachines)
        {
            if (!requiredMachines.Any()) return 100;

            var availableTypes = machines.Select(m => m.Type.ToString()).Distinct().ToList();
            var matchCount = requiredMachines.Count(rm => availableTypes.Contains(rm));

            return (double)matchCount / requiredMachines.Count * 100;
        }

        private DateTime GetNextAvailableTime(ProductionLine line, DateTime currentTime)
        {
            if (line.ScheduledTasks.Count == 0) return currentTime;

            var lastTask = line.ScheduledTasks.OrderBy(t => t.EndTime).LastOrDefault();
            return lastTask?.EndTime ?? currentTime;
        }

        private List<TimeSpan> AnalyzeTaskGaps(List<ScheduledTask> tasks)
        {
            var gaps = new List<TimeSpan>();
            var sortedTasks = tasks.OrderBy(t => t.StartTime).ToList();

            for (int i = 1; i < sortedTasks.Count; i++)
            {
                var gap = sortedTasks[i].StartTime - sortedTasks[i - 1].EndTime;
                if (gap.TotalMinutes > 0)
                    gaps.Add(gap);
            }

            return gaps;
        }

        private double AnalyzeResourceUtilization(List<ScheduledTask> tasks)
        {
            if (tasks.Count == 0) return 0;

            var totalDuration = tasks.Sum(t => (t.EndTime - t.StartTime).TotalHours);
            var timeSpan = tasks.Max(t => t.EndTime) - tasks.Min(t => t.StartTime);

            return (totalDuration / timeSpan.TotalHours) * 100;
        }

        private List<ScheduledTask> AnalyzeDeliveryRisks(List<ScheduledTask> tasks)
        {
            // 这里应该结合订单的交期信息来分析
            // 简化实现：假设超过3天的任务有交期风险
            var riskThreshold = DateTime.Now.AddDays(3);
            return tasks.Where(t => t.EndTime > riskThreshold).ToList();
        }
    }

    // Semantic Kernel插件 - 生产分析
    public class ProductionAnalysisPlugin
    {
        private readonly IProductionDataService _dataService;
        private readonly ILogger<ProductionAnalysisPlugin> _logger;

        public ProductionAnalysisPlugin(IProductionDataService dataService, ILogger<ProductionAnalysisPlugin> logger)
        {
            _dataService = dataService;
            _logger = logger;
        }

        [KernelFunction("AnalyzeProductionAnomalies")]
        [Description("分析生产线数据并提供AI驱动的优化建议")]
        public async Task<string> AnalyzeProductionAnomaliesAsync(
            [Description("生产线ID")] string lineId,
            Kernel kernel)
        {
            try
            {
                _logger.LogInformation($"🤖 开始AI分析生产线 {lineId}");

                // 获取生产数据
                var data = await _dataService.GetProductionDataAsync(lineId, TimeSpan.FromHours(24));

                // 准备数据摘要
                var avgEfficiency = data.Average(d => d.Efficiency);
                var avgDefectRate = data.Average(d => (double)d.DefectCount / Math.Max(d.ProductionCount, 1) * 100);
                var avgDowntime = data.Average(d => d.DowntimeMinutes);
                var totalProduction = data.Sum(d => d.ProductionCount);

                // 构建给AI的分析提示
                var prompt = $@"
作为生产制造专家，请分析以下生产线数据并提供专业建议：

生产线ID: {lineId}
分析时间段: 过去24小时
数据点数量: {data.Count}

关键指标：
- 平均生产效率: {avgEfficiency:F2}% (行业标准: >85%)
- 平均不良率: {avgDefectRate:F2}% (行业标准: <2%)
- 平均停机时间: {avgDowntime:F2}分钟/小时 (行业标准: <30分钟)
- 总产量: {totalProduction} 件

详细数据趋势：
{string.Join("\n", data.TakeLast(8).Select(d =>
    $"时间: {d.Timestamp:HH:mm} | 效率: {d.Efficiency:F1}% | 产量: {d.ProductionCount} | 不良: {d.DefectCount} | 停机: {d.DowntimeMinutes:F1}分钟"))}

请基于以上数据：
1. 识别主要问题和异常
2. 分析可能的根本原因
3. 提供具体的改善建议
4. 预估改善后的效果

请以JSON格式返回分析结果，包含：
- 发现的异常 (anomalies)
- 问题分析 (analysis)
- 改善建议 (recommendations)
- 预期效果 (expectedResults)
";

                // 调用AI进行分析
                var response = await kernel.InvokePromptAsync(prompt);
                var aiAnalysis = response.GetValue<string>();

                _logger.LogInformation($"✅ AI分析完成: {lineId}");

                // 尝试解析AI返回的结果，如果不是JSON格式则包装成JSON
                try
                {
                    JsonDocument.Parse(aiAnalysis);
                    return aiAnalysis;
                }
                catch
                {
                    // 如果AI返回的不是JSON，包装成标准格式
                    var wrappedResult = new
                    {
                        LineId = lineId,
                        AnalysisTime = DateTime.Now,
                        AIAnalysis = aiAnalysis,
                        DataSummary = new
                        {
                            AvgEfficiency = avgEfficiency,
                            AvgDefectRate = avgDefectRate,
                            AvgDowntime = avgDowntime,
                            TotalProduction = totalProduction,
                            DataPoints = data.Count
                        }
                    };
                    return JsonSerializer.Serialize(wrappedResult, new JsonSerializerOptions { WriteIndented = true });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AI分析生产线异常失败: LineId={LineId}", lineId);
                return JsonSerializer.Serialize(new
                {
                    LineId = lineId,
                    Error = $"AI分析失败: {ex.Message}",
                    Timestamp = DateTime.Now
                });
            }
        }

        [KernelFunction("GenerateSchedulingRecommendations")]
        [Description("基于AI生成智能排程优化建议")]
        public async Task<string> GenerateSchedulingRecommendationsAsync(
            [Description("当前排程数据JSON")] string scheduleJson,
            Kernel kernel)
        {
            try
            {
                _logger.LogInformation("🤖 开始生成AI排程建议");

                var prompt = $@"
作为生产排程专家，请分析以下排程数据并提供智能优化建议：

当前排程数据:
{scheduleJson}

请基于以上排程信息：
1. 评估当前排程的合理性
2. 识别潜在的优化点
3. 考虑资源利用率、交期风险、效率等因素
4. 提供具体可行的优化建议
5. 预估优化后的收益

特别关注：
- 生产线负荷均衡
- 关键路径优化
- 资源冲突预防
- 交期风险管控
- 切换成本最小化

请以结构化的方式返回建议，包含优先级排序和具体的实施步骤。
";

                var response = await kernel.InvokePromptAsync(prompt);
                var aiRecommendations = response.GetValue<string>();

                _logger.LogInformation("✅ AI排程建议生成完成");

                var result = new
                {
                    Timestamp = DateTime.Now,
                    Type = "AI_SchedulingOptimization",
                    AIRecommendations = aiRecommendations,
                    InputData = scheduleJson
                };

                return JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AI生成排程建议失败");
                return JsonSerializer.Serialize(new
                {
                    Error = $"AI排程建议生成失败: {ex.Message}",
                    Timestamp = DateTime.Now
                });
            }
        }
    }

    // 主调度器
    public class ProductionScheduler
    {
        private readonly Kernel _kernel;
        private readonly IProductionDataService _dataService;
        private readonly ISchedulingEngine _schedulingEngine;
        private readonly ProductionAnalysisPlugin _analysisPlugin;
        private readonly ILogger<ProductionScheduler> _logger;

        public ProductionScheduler(
            Kernel kernel,
            IProductionDataService dataService,
            ISchedulingEngine schedulingEngine,
            ProductionAnalysisPlugin analysisPlugin,
            ILogger<ProductionScheduler> logger)
        {
            _kernel = kernel;
            _dataService = dataService;
            _schedulingEngine = schedulingEngine;
            _analysisPlugin = analysisPlugin;
            _logger = logger;

            // 正确的插件注册方式
            _kernel.Plugins.AddFromObject(_analysisPlugin, "ProductionAnalysisPlugin");
        }

        public async Task RunSchedulingSystemAsync()
        {
            _logger.LogInformation("=== 🚀 生产计划智能排程系统启动 ===");

            try
            {
                // 1. 获取待排程订单
                var pendingOrders = await _dataService.GetPendingOrdersAsync();
                _logger.LogInformation($"获取到 {pendingOrders.Count} 个待排程订单");

                // 2. 获取生产线信息
                var productionLines = await _dataService.GetProductionLinesAsync();
                _logger.LogInformation($"获取到 {productionLines.Count} 条生产线");

                // 3. 生成排程
                var scheduledTasks = await _schedulingEngine.GenerateScheduleAsync(pendingOrders, productionLines);
                _logger.LogInformation($"生成了 {scheduledTasks.Count} 个排程任务");

                // 4. 计算排程效率
                var efficiency = await _schedulingEngine.CalculateScheduleEfficiencyAsync(scheduledTasks);
                _logger.LogInformation($"排程效率: {efficiency:F2}%");

                // 5. 显示排程结果
                DisplayScheduleResults(scheduledTasks, pendingOrders);

                // 6. AI分析和优化建议
                await RunAIAnalysisAsync(productionLines);

                // 7. 优化建议
                var optimizations = await _schedulingEngine.OptimizeScheduleAsync(scheduledTasks);
                DisplayOptimizationRecommendations(optimizations);

                // 8. 生成AI排程建议
                await GenerateAISchedulingRecommendationsAsync(scheduledTasks);

                // 9. 保存排程任务
                foreach (var task in scheduledTasks)
                {
                    await _dataService.SaveScheduledTaskAsync(task);
                    await _dataService.UpdateOrderStatusAsync(task.OrderId, OrderStatus.Scheduled);
                }

                // 10. 显示系统统计
                DisplaySystemStatistics(scheduledTasks, efficiency);

                _logger.LogInformation("=== ✅ 排程系统运行完成 ===");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ 排程系统运行失败");
            }
        }

        private void DisplayScheduleResults(List<ScheduledTask> tasks, List<ProductionOrder> orders)
        {
            Console.WriteLine("\n=== 📋 排程结果详情 ===");
            Console.WriteLine($"{"任务ID",-12} {"订单ID",-10} {"产品名称",-15} {"生产线",-12} {"开始时间",-16} {"结束时间",-16} {"状态",-10}");
            Console.WriteLine(new string('-', 110));

            foreach (var task in tasks.OrderBy(t => t.StartTime))
            {
                var order = orders.FirstOrDefault(o => o.OrderId == task.OrderId);
                var productName = order?.ProductName ?? "未知产品";
                if (productName.Length > 14) productName = productName.Substring(0, 11) + "...";

                Console.WriteLine($"{task.TaskId,-12} {task.OrderId,-10} {productName,-15} {task.LineId,-12} " +
                                $"{task.StartTime:MM-dd HH:mm,-16} {task.EndTime:MM-dd HH:mm,-16} {task.Status,-10}");
            }

            // 显示未排程的订单
            var unscheduledOrders = orders.Where(o => !tasks.Any(t => t.OrderId == o.OrderId)).ToList();
            if (unscheduledOrders.Any())
            {
                Console.WriteLine("\n=== ⚠️ 未排程订单 ===");
                foreach (var order in unscheduledOrders)
                {
                    Console.WriteLine($"订单 {order.OrderId}: {order.ProductName} - 原因：缺少必要资源或技能");
                }
            }
        }

        private async Task RunAIAnalysisAsync(List<ProductionLine> lines)
        {
            Console.WriteLine("\n=== 🤖 AI智能分析报告 ===");

            foreach (var line in lines)
            {
                try
                {
                    Console.WriteLine($"📊 正在分析生产线 {line.LineId} ({line.LineName})...");

                    // 调用AI分析函数，传入kernel参数
                    var analysisResult = await _analysisPlugin.AnalyzeProductionAnomaliesAsync(line.LineId, _kernel);

                    var jsonResult = JsonDocument.Parse(analysisResult);

                    if (jsonResult.RootElement.TryGetProperty("AIAnalysis", out var aiAnalysis))
                    {
                        Console.WriteLine($"\n🧠 AI分析结果:");
                        Console.WriteLine($"{aiAnalysis.GetString()}");
                    }
                    else if (jsonResult.RootElement.TryGetProperty("DataSummary", out var summary))
                    {
                        Console.WriteLine("📈 数据摘要:");
                        if (summary.TryGetProperty("AvgEfficiency", out var efficiency))
                            Console.WriteLine($"   • 平均效率: {efficiency.GetDouble():F2}%");
                        if (summary.TryGetProperty("AvgDefectRate", out var defectRate))
                            Console.WriteLine($"   • 不良率: {defectRate.GetDouble():F2}%");
                        if (summary.TryGetProperty("TotalProduction", out var totalProd))
                            Console.WriteLine($"   • 总产量: {totalProd.GetInt32()} 件");
                    }

                    Console.WriteLine($"✅ 生产线 {line.LineId} AI分析完成\n");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"AI分析生产线 {line.LineId} 失败");
                    Console.WriteLine($"❌ AI分析生产线 {line.LineId} 时出错: {ex.Message}");
                }
            }
        }

        private void DisplayOptimizationRecommendations(List<OptimizationRecommendation> recommendations)
        {
            Console.WriteLine("\n=== 🎯 传统优化建议 ===");

            if (!recommendations.Any())
            {
                Console.WriteLine("✅ 当前排程已达到较好的优化状态，暂无传统优化建议");
                return;
            }

            foreach (var rec in recommendations.OrderByDescending(r => r.Priority == "Critical" ? 3 : r.Priority == "High" ? 2 : 1))
            {
                var priorityIcon = rec.Priority switch
                {
                    "Critical" => "🔴",
                    "High" => "🟡",
                    "Medium" => "🟢",
                    _ => "⚪"
                };

                Console.WriteLine($"\n{priorityIcon} 类别: {rec.Category} | 优先级: {rec.Priority}");
                Console.WriteLine($"📋 描述: {rec.Description}");
                Console.WriteLine($"📈 预期改善: {rec.ExpectedImprovement:F1}%");
                Console.WriteLine("🔧 建议行动:");
                foreach (var action in rec.ActionItems)
                {
                    Console.WriteLine($"   • {action}");
                }
            }
        }

        private async Task GenerateAISchedulingRecommendationsAsync(List<ScheduledTask> tasks)
        {
            Console.WriteLine("\n=== 🧠 AI排程优化建议 ===");

            try
            {
                Console.WriteLine("🤖 正在生成AI排程优化建议...");

                var scheduleData = JsonSerializer.Serialize(tasks.Select(t => new
                {
                    t.TaskId,
                    t.OrderId,
                    t.LineId,
                    StartTime = t.StartTime.ToString("yyyy-MM-dd HH:mm"),
                    EndTime = t.EndTime.ToString("yyyy-MM-dd HH:mm"),
                    Duration = (t.EndTime - t.StartTime).TotalHours,
                    AssignedMachines = t.AssignedMachines,
                    AssignedWorkers = t.AssignedWorkers
                }), new JsonSerializerOptions { WriteIndented = true });

                var aiRecommendations = await _analysisPlugin.GenerateSchedulingRecommendationsAsync(scheduleData, _kernel);

                var jsonResult = JsonDocument.Parse(aiRecommendations);

                if (jsonResult.RootElement.TryGetProperty("AIRecommendations", out var recommendations))
                {
                    Console.WriteLine("🎯 AI智能建议:");
                    Console.WriteLine(recommendations.GetString());
                }

                Console.WriteLine("✅ AI排程建议生成完成");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "生成AI排程建议失败");
                Console.WriteLine($"❌ 生成AI建议时出错: {ex.Message}");
            }
        }

        private void DisplaySystemStatistics(List<ScheduledTask> tasks, double efficiency)
        {
            Console.WriteLine("\n=== 📊 系统运行统计 ===");

            if (tasks.Any())
            {
                var totalDuration = tasks.Sum(t => (t.EndTime - t.StartTime).TotalHours);
                var timeSpan = tasks.Max(t => t.EndTime) - tasks.Min(t => t.StartTime);
                var avgTaskDuration = tasks.Average(t => (t.EndTime - t.StartTime).TotalHours);

                Console.WriteLine($"📅 排程时间范围: {tasks.Min(t => t.StartTime):MM-dd HH:mm} ~ {tasks.Max(t => t.EndTime):MM-dd HH:mm}");
                Console.WriteLine($"⏱️  总计划用时: {totalDuration:F1} 小时");
                Console.WriteLine($"⏰ 平均任务时长: {avgTaskDuration:F1} 小时");
                Console.WriteLine($"📈 排程效率: {efficiency:F2}%");
                Console.WriteLine($"✅ 成功排程任务: {tasks.Count} 个");

                // 按生产线统计
                var lineStats = tasks.GroupBy(t => t.LineId)
                    .Select(g => new { LineId = g.Key, TaskCount = g.Count(), TotalHours = g.Sum(t => (t.EndTime - t.StartTime).TotalHours) })
                    .OrderByDescending(s => s.TaskCount);

                Console.WriteLine("\n📋 各生产线负荷:");
                foreach (var stat in lineStats)
                {
                    Console.WriteLine($"   • {stat.LineId}: {stat.TaskCount} 个任务, {stat.TotalHours:F1} 小时");
                }
            }
            else
            {
                Console.WriteLine("❌ 未能生成任何有效的排程任务");
            }
        }
    }
}
