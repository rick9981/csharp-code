﻿using System.Text;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Microsoft.SemanticKernel;
using System.Data;
using System.Data.SQLite;

namespace AppDbAiAgent
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // 检查是否需要初始化数据库
            if (!File.Exists("test.db"))
            {
                Console.WriteLine("🔧 正在初始化SCADA数据库...");
                DatabaseInitializer.InitializeScadaDatabase();
                Console.WriteLine();
            }

            // 显示数据库统计信息
            DatabaseInitializer.ShowDatabaseStatistics();
            Console.WriteLine();

            // Kernel 初始化及AI服务连接
            var kernel = InitializeKernel();

            // 插件注册
            RegisterDatabaseQueryPlugin(kernel);

            // 启动聊天循环
            await StartChatLoop(kernel);
        }

        /// <summary>
        /// 初始化Kernel
        /// </summary>
        static Kernel InitializeKernel()
        {
            var kernelBuilder = Kernel.CreateBuilder();
            kernelBuilder.AddOpenAIChatCompletion(
                modelId: "deepseek-chat",
                apiKey: Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY") ?? "sk-xxx",
                endpoint: new Uri("https://api.deepseek.com/v1")
            );
            return kernelBuilder.Build();
        }

        /// <summary>
        /// 启动聊天循环
        /// </summary>
        static async Task StartChatLoop(Kernel kernel)
        {
            // 聊天历史管理
            var chatHistory = new ChatHistory();
            chatHistory.AddSystemMessage(@"你是一个智能学习助手，具备数据查询与分析能力，
请根据用户需求选择合适的工具来协助用户。");

            Console.WriteLine("🤖 欢迎使用智能AI数据助手！");
            Console.WriteLine("📝 输入 'exit' 可随时退出\n");

            while (true)
            {
                Console.Write("👤 您: ");
                string userInput = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(userInput)) continue;
                if (userInput.Trim().ToLower() == "exit") break;

                // 添加用户消息到历史
                chatHistory.AddUserMessage(userInput);

                try
                {
                    Console.Write("🤖 AI助手: ");

                    // 处理AI响应
                    await ProcessAIResponse(kernel, chatHistory);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ 发生错误: {ex.Message}\n");
                }
            }

            Console.WriteLine("👋 感谢使用，再见！");
        }

        /// <summary>
        /// 处理AI响应
        /// </summary>
        static async Task ProcessAIResponse(Kernel kernel, ChatHistory chatHistory)
        {
            // 获取聊天完成服务
            var chatCompletionService = kernel.GetRequiredService<IChatCompletionService>();

            // 配置执行设置 - 启用自动函数调用
            var executionSettings = new OpenAIPromptExecutionSettings
            {
                ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions,
                MaxTokens = 2000,
                Temperature = 0.7
            };

            // 流式响应输出
            var streamResponse = chatCompletionService.GetStreamingChatMessageContentsAsync(
                chatHistory: chatHistory,
                executionSettings: executionSettings,
                kernel: kernel
            );

            string fullResponse = "";
            bool isFirstToken = true;

            await foreach (var content in streamResponse)
            {
                if (!string.IsNullOrEmpty(content.Content))
                {
                    // 第一个token前添加一个小延迟，模拟思考
                    if (isFirstToken)
                    {
                        await Task.Delay(100);
                        isFirstToken = false;
                    }

                    Console.Write(content.Content);
                    fullResponse += content.Content;

                    // 添加微小延迟，让输出更自然
                    await Task.Delay(20);
                }
            }

            Console.WriteLine("\n");

            // 将完整响应添加到聊天历史
            if (!string.IsNullOrWhiteSpace(fullResponse))
            {
                chatHistory.AddAssistantMessage(fullResponse);
            }
        }


        static void RegisterDatabaseQueryPlugin(Kernel kernel)
        {
            // 1. 获取数据库结构的函数
            var getSchemaFunction = kernel.CreateFunctionFromMethod(
                method: () =>
                {
                    try
                    {
                        var dbFilePath = "test.db";
                        if (!File.Exists(dbFilePath))
                            return "数据库文件不存在。";

                        using var connection = new SQLiteConnection($"Data Source={dbFilePath};Version=3;");
                        connection.Open();

                        var schema = GetDatabaseSchema(connection);
                        return schema;
                    }
                    catch (Exception ex)
                    {
                        return $"获取数据库结构失败: {ex.Message}";
                    }
                },
                functionName: "GetDatabaseSchema",
                description: "获取数据库的完整结构信息，包括所有表、字段、数据类型等"
            );

            // 2. 智能SQL查询函数（带结构感知）
            var smartQueryFunction = kernel.CreateFunctionFromMethod(
                method: (string userQuestion) =>
                {
                    try
                    {
                        var dbFilePath = "test.db";
                        if (!File.Exists(dbFilePath))
                            return "数据库文件不存在。";

                        using var connection = new SQLiteConnection($"Data Source={dbFilePath};Version=3;");
                        connection.Open();

                        // 获取数据库结构
                        var schema = GetDatabaseSchema(connection);

                        // 返回结构信息供AI参考
                        return $"数据库结构信息：\n{schema}\n\n用户问题：{userQuestion}\n\n请根据上述数据库结构生成合适的SQL查询语句。";
                    }
                    catch (Exception ex)
                    {
                        return $"查询失败: {ex.Message}";
                    }
                },
                functionName: "AnalyzeQueryRequest",
                description: "分析用户查询需求并提供数据库结构信息，帮助生成正确的SQL语句"
            );

            // 3. 执行SQL的函数
            var executeQueryFunction = kernel.CreateFunctionFromMethod(
                method: (string sql) =>
                {
                    try
                    {
                        var dbFilePath = "test.db";
                        if (!File.Exists(dbFilePath))
                            return "数据库文件不存在。";

                        using var connection = new SQLiteConnection($"Data Source={dbFilePath};Version=3;");
                        connection.Open();

                        // 安全检查：只允许SELECT语句
                        if (!sql.Trim().ToUpper().StartsWith("SELECT"))
                        {
                            return "⚠️ 出于安全考虑，只允许执行SELECT查询语句。";
                        }

                        using var command = new SQLiteCommand(sql, connection);
                        using var reader = command.ExecuteReader();

                        var dt = new DataTable();
                        dt.Load(reader);

                        if (dt.Rows.Count == 0)
                            return "查询结果为空。";

                        return FormatQueryResult(dt);
                    }
                    catch (Exception ex)
                    {
                        return $"SQL执行出错: {ex.Message}";
                    }
                },
                functionName: "ExecuteSQL",
                description: "执行SQL查询语句并返回格式化的结果"
            );

            kernel.ImportPluginFromFunctions("DatabasePlugin", [getSchemaFunction, smartQueryFunction, executeQueryFunction]);
        }

        /// <summary>
        /// 获取数据库结构信息
        /// </summary>
        private static string GetDatabaseSchema(SQLiteConnection connection)
        {
            var schema = new StringBuilder();
            schema.AppendLine("📊 SCADA数据库结构信息");
            schema.AppendLine("=" + new string('=', 50));

            // 获取所有表名
            var tables = GetTableNames(connection);

            foreach (var tableName in tables)
            {
                schema.AppendLine($"\n🔹 表名: {tableName}");
                schema.AppendLine($"   字段信息:");

                // 获取表结构
                var tableInfo = GetTableStructure(connection, tableName);
                foreach (var column in tableInfo)
                {
                    schema.AppendLine($"   - {column.Name} ({column.Type}) {(column.IsPrimaryKey ? "[主键]" : "")} {(column.IsNotNull ? "[非空]" : "")}");
                }

                // 获取记录数
                var count = GetTableRecordCount(connection, tableName);
                schema.AppendLine($"   📋 记录数: {count}");

                // 获取外键信息
                var foreignKeys = GetForeignKeys(connection, tableName);
                if (foreignKeys.Any())
                {
                    schema.AppendLine($"   🔗 外键关系:");
                    foreach (var fk in foreignKeys)
                    {
                        schema.AppendLine($"   - {fk.Column} -> {fk.RefTable}.{fk.RefColumn}");
                    }
                }
            }

            schema.AppendLine($"\n💡 使用示例:");
            schema.AppendLine($"   - 查询所有设备: SELECT * FROM Devices");
            schema.AppendLine($"   - 查询运行状态的设备: SELECT * FROM Devices WHERE Status = '运行'");
            schema.AppendLine($"   - 查询最近的报警: SELECT * FROM Alarms ORDER BY AlarmTime DESC LIMIT 10");
            schema.AppendLine($"   - 统计设备类型: SELECT DeviceType, COUNT(*) FROM Devices GROUP BY DeviceType");

            return schema.ToString();
        }

        /// <summary>
        /// 获取所有表名
        /// </summary>
        private static List<string> GetTableNames(SQLiteConnection connection)
        {
            var tables = new List<string>();
            string sql = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'";

            using var command = new SQLiteCommand(sql, connection);
            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                tables.Add(reader.GetString(0));
            }

            return tables;
        }

        /// <summary>
        /// 获取表结构信息
        /// </summary>
        private static List<ColumnInfo> GetTableStructure(SQLiteConnection connection, string tableName)
        {
            var columns = new List<ColumnInfo>();
            string sql = $"PRAGMA table_info({tableName})";

            using var command = new SQLiteCommand(sql, connection);
            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                columns.Add(new ColumnInfo
                {
                    Name = reader.GetString("name"),
                    Type = reader.GetString("type"),
                    IsNotNull = reader.GetBoolean("notnull"),
                    IsPrimaryKey = reader.GetBoolean("pk")
                });
            }

            return columns;
        }

        /// <summary>
        /// 获取表记录数
        /// </summary>
        private static int GetTableRecordCount(SQLiteConnection connection, string tableName)
        {
            string sql = $"SELECT COUNT(*) FROM {tableName}";
            using var command = new SQLiteCommand(sql, connection);
            return Convert.ToInt32(command.ExecuteScalar());
        }

        /// <summary>
        /// 获取外键信息
        /// </summary>
        private static List<ForeignKeyInfo> GetForeignKeys(SQLiteConnection connection, string tableName)
        {
            var foreignKeys = new List<ForeignKeyInfo>();
            string sql = $"PRAGMA foreign_key_list({tableName})";

            using var command = new SQLiteCommand(sql, connection);
            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                foreignKeys.Add(new ForeignKeyInfo
                {
                    Column = reader.GetString("from"),
                    RefTable = reader.GetString("table"),
                    RefColumn = reader.GetString("to")
                });
            }

            return foreignKeys;
        }

        /// <summary>
        /// 格式化查询结果
        /// </summary>
        private static string FormatQueryResult(DataTable dt)
        {
            var result = new StringBuilder();
            result.AppendLine($"📋 查询结果 (共 {dt.Rows.Count} 条记录):");
            result.AppendLine(new string('=', 60));

            // 列标题
            foreach (DataColumn col in dt.Columns)
            {
                result.Append($"{col.ColumnName,-15} | ");
            }
            result.AppendLine();
            result.AppendLine(new string('-', 60));

            // 数据行（限制显示前20行）
            int maxRows = Math.Min(20, dt.Rows.Count);
            for (int i = 0; i < maxRows; i++)
            {
                foreach (var item in dt.Rows[i].ItemArray)
                {
                    string value = item?.ToString() ?? "NULL";
                    if (value.Length > 12) value = value.Substring(0, 12) + "...";
                    result.Append($"{value,-15} | ");
                }
                result.AppendLine();
            }

            if (dt.Rows.Count > 20)
            {
                result.AppendLine($"... 还有 {dt.Rows.Count - 20} 条记录未显示");
            }

            return result.ToString();
        }

        /// <summary>
        /// 列信息类
        /// </summary>
        public class ColumnInfo
        {
            public string Name { get; set; }
            public string Type { get; set; }
            public bool IsNotNull { get; set; }
            public bool IsPrimaryKey { get; set; }
        }

        /// <summary>
        /// 外键信息类
        /// </summary>
        public class ForeignKeyInfo
        {
            public string Column { get; set; }
            public string RefTable { get; set; }
            public string RefColumn { get; set; }
        }
    }
}
