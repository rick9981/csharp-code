﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections.Concurrent;

namespace AppAiIndustryNetworkMonitor
{
    public class NetworkTrafficService : IDisposable
    {
        private readonly ConcurrentBag<NetworkTrafficRecord> _trafficRecords;
        private readonly List<NetworkDevice> _networkDevices;
        private readonly ConcurrentBag<NetworkThreat> _detectedThreats;
        private readonly Random _random;
        private Timer _trafficGenerationTimer;
        private Timer _threatDetectionTimer;
        private Timer _deviceStatusUpdateTimer;
        private readonly object _lockObject = new object();

        // 配置参数  
        private readonly int _maxRecordsInMemory = 10000; // 内存中保留的最大记录数  
        private readonly TimeSpan _recordRetentionPeriod = TimeSpan.FromHours(24); // 记录保留时间  
        private readonly int _recordsPerSecond = 5; // 每秒生成的记录数  

        public NetworkTrafficService()
        {
            _trafficRecords = new ConcurrentBag<NetworkTrafficRecord>();
            _networkDevices = new List<NetworkDevice>();
            _detectedThreats = new ConcurrentBag<NetworkThreat>();
            _random = new Random();

            // 初始化静态数据  
            InitializeIndustrialDevices();

            // 启动实时数据生成定时器  
            StartRealTimeGeneration();
        }

        private void StartRealTimeGeneration()
        {
            _trafficGenerationTimer = new Timer(GenerateRealtimeTraffic, null, TimeSpan.Zero, TimeSpan.FromMilliseconds(200));
            _threatDetectionTimer = new Timer(DetectThreats, null, TimeSpan.FromSeconds(10), TimeSpan.FromSeconds(30));
            _deviceStatusUpdateTimer = new Timer(UpdateDeviceStatus, null, TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(5));
        }

        private void GenerateRealtimeTraffic(object state)
        {
            try
            {
                int recordCount = _random.Next(1, 4);

                for (int i = 0; i < recordCount; i++)
                {
                    var record = GenerateTrafficRecord();
                    _trafficRecords.Add(record);
                    if (record.TrafficType != TrafficType.Normal && _random.NextDouble() < 0.3)
                    {
                        GenerateRelatedThreat(record);
                    }
                }
                // 定期清理旧记录
                if (_random.Next(0, 100) < 5)
                {
                    CleanupOldRecords();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"生成实时流量数据时发生错误: {ex.Message}");
            }
        }

        private NetworkTrafficRecord GenerateTrafficRecord()
        {
            var protocols = Enum.GetValues<NetworkProtocol>();
            var segments = Enum.GetValues<NetworkSegment>();
            var currentHour = DateTime.Now.Hour;
            var isBusinessHour = currentHour >= 8 && currentHour <= 18;
            var trafficMultiplier = isBusinessHour ? 1.5 : 0.7;

            var record = new NetworkTrafficRecord
            {
                Timestamp = DateTime.Now,
                SourceIP = GenerateRealisticIP(),
                DestinationIP = GenerateRealisticIP(),
                SourcePort = GenerateRealisticSourcePort(),
                DestinationPort = GenerateRealisticDestinationPort(),
                Protocol = GenerateWeightedProtocol(),
                BytesSent = (long)(_random.Next(100, 50000) * trafficMultiplier),
                BytesReceived = (long)(_random.Next(100, 50000) * trafficMultiplier),
                PacketCount = _random.Next(5, 500),
                Duration = _random.NextDouble() * 30,
                TrafficType = DetermineRealisticTrafficType(),
                Segment = GenerateWeightedSegment(),
                Latency = GenerateRealisticLatency(),
                PacketLoss = GenerateRealisticPacketLoss(),
                DeviceType = GetWeightedDeviceType()
            };

            if (record.TrafficType != TrafficType.Normal)
            {
                record.AlertMessage = GenerateDetailedAlertMessage(record);
            }

            return record;
        }

        private void DetectThreats(object state)
        {
            try
            {
                // 分析最近的流量记录，检测威胁  
                var recentRecords = GetRecentRecords(TimeSpan.FromMinutes(10));

                // 检测端口扫描  
                DetectPortScans(recentRecords);

                // 检测DDoS攻击  
                DetectDDoSAttacks(recentRecords);

                // 检测异常通信  
                DetectAnomalousCommunication(recentRecords);

                // 检测协议异常  
                DetectProtocolAnomalies(recentRecords);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"威胁检测时发生错误: {ex.Message}");
            }
        }

        private void UpdateDeviceStatus(object state)
        {
            try
            {
                lock (_lockObject)
                {
                    foreach (var device in _networkDevices)
                    {
                        // 随机更新设备状态  
                        if (_random.NextDouble() < 0.1)
                        {
                            device.IsOnline = _random.NextDouble() > 0.05;
                        }

                        if (device.IsOnline)
                        {
                            device.LastSeen = DateTime.Now.AddSeconds(_random.Next(-30, 0));
  
                            device.AverageLatency += (_random.NextDouble() - 0.5) * 2;
                            device.AverageLatency = Math.Max(1, Math.Min(200, device.AverageLatency));
                            device.TotalTraffic += _random.Next(1000, 100000);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"更新设备状态时发生错误: {ex.Message}");
            }
        }

        private List<NetworkTrafficRecord> GetRecentRecords(TimeSpan timeSpan)
        {
            var cutoffTime = DateTime.Now - timeSpan;
            return _trafficRecords.Where(r => r.Timestamp >= cutoffTime).ToList();
        }

        private void DetectPortScans(List<NetworkTrafficRecord> recentRecords)
        {
            // 检测来自同一IP的多端口访问  
            var portScanThreshold = 10; // 10个不同端口  

            var suspiciousIPs = recentRecords
                .GroupBy(r => r.SourceIP)
                .Where(g => g.Select(r => r.DestinationPort).Distinct().Count() >= portScanThreshold)
                .Select(g => g.Key)
                .ToList();

            foreach (var ip in suspiciousIPs)
            {
                if (_detectedThreats.Any(t => t.SourceIP == ip && t.ThreatType == "Port Scan" &&
                                             (DateTime.Now - t.DetectedTime).TotalMinutes < 30))
                    continue;

                var threat = new NetworkThreat
                {
                    DetectedTime = DateTime.Now,
                    ThreatType = "Port Scan",
                    Severity = "High",
                    SourceIP = ip,
                    TargetIP = GetMostTargetedIP(recentRecords, ip),
                    Description = $"检测到来自 {ip} 的端口扫描活动，扫描了多个端口",
                    RecommendedAction = "立即阻断该IP地址，并进行深度调查",
                    IsResolved = false
                };

                _detectedThreats.Add(threat);
            }
        }

        private void DetectDDoSAttacks(List<NetworkTrafficRecord> recentRecords)
        {
            var ddosThreshold = 100; // 100个连接/分钟  

            var suspiciousTargets = recentRecords
                .GroupBy(r => r.DestinationIP)
                .Where(g => g.Count() >= ddosThreshold)
                .Select(g => new { IP = g.Key, Count = g.Count() })
                .ToList();

            foreach (var target in suspiciousTargets)
            {
                if (_detectedThreats.Any(t => t.TargetIP == target.IP && t.ThreatType == "DDoS Attack" &&
                                             (DateTime.Now - t.DetectedTime).TotalMinutes < 15))
                    continue;

                var threat = new NetworkThreat
                {
                    DetectedTime = DateTime.Now,
                    ThreatType = "DDoS Attack",
                    Severity = target.Count > 200 ? "Critical" : "High",
                    SourceIP = "Multiple Sources",
                    TargetIP = target.IP,
                    Description = $"检测到针对 {target.IP} 的DDoS攻击，连接数: {target.Count}",
                    RecommendedAction = "启动DDoS防护措施，限制连接速率",
                    IsResolved = false
                };

                _detectedThreats.Add(threat);
            }
        }

        private void DetectAnomalousCommunication(List<NetworkTrafficRecord> recentRecords)
        {
            // 检测异常大数据传输  
            var largeTraficThreshold = 10_000_000; // 10MB  

            var largeTransfers = recentRecords
                .Where(r => r.BytesSent + r.BytesReceived > largeTraficThreshold)
                .ToList();

            foreach (var transfer in largeTransfers)
            {
                var threat = new NetworkThreat
                {
                    DetectedTime = DateTime.Now,
                    ThreatType = "Data Exfiltration",
                    Severity = "Medium",
                    SourceIP = transfer.SourceIP,
                    TargetIP = transfer.DestinationIP,
                    Description = $"检测到异常大数据传输: {(transfer.BytesSent + transfer.BytesReceived) / 1024 / 1024:F1}MB",
                    RecommendedAction = "调查数据传输的合法性",
                    IsResolved = false
                };

                _detectedThreats.Add(threat);
            }
        }

        private void DetectProtocolAnomalies(List<NetworkTrafficRecord> recentRecords)
        {
            // 检测工业协议的异常使用  
            var industrialProtocols = new[] { NetworkProtocol.Modbus, NetworkProtocol.EtherNetIP, NetworkProtocol.OPCua, NetworkProtocol.Profinet };

            var anomalousRecords = recentRecords
                .Where(r => industrialProtocols.Contains(r.Protocol) &&
                           (r.Latency > 100 || r.PacketLoss > 5))
                .ToList();

            foreach (var record in anomalousRecords)
            {
                var threat = new NetworkThreat
                {
                    DetectedTime = DateTime.Now,
                    ThreatType = "Protocol Anomaly",
                    Severity = "Medium",
                    SourceIP = record.SourceIP,
                    TargetIP = record.DestinationIP,
                    Description = $"检测到 {record.Protocol} 协议异常，延迟: {record.Latency:F1}ms, 丢包率: {record.PacketLoss:F1}%",
                    RecommendedAction = "检查设备连接和网络配置",
                    IsResolved = false
                };

                _detectedThreats.Add(threat);
            }
        }

        private void GenerateRelatedThreat(NetworkTrafficRecord record)
        {
            var threatTypes = new[] { "Unauthorized Access", "Malware Communication", "Suspicious Activity" };
            var threat = new NetworkThreat
            {
                DetectedTime = DateTime.Now,
                ThreatType = threatTypes[_random.Next(threatTypes.Length)],
                Severity = record.TrafficType == TrafficType.Emergency ? "Critical" : "Medium",
                SourceIP = record.SourceIP,
                TargetIP = record.DestinationIP,
                Description = $"基于流量模式检测到的威胁: {record.AlertMessage}",
                RecommendedAction = GetThreatRecommendation(record.TrafficType),
                IsResolved = false
            };

            _detectedThreats.Add(threat);
        }

        private void CleanupOldRecords()
        {
            var cutoffTime = DateTime.Now - _recordRetentionPeriod;

            var recentRecords = _trafficRecords.Where(r => r.Timestamp >= cutoffTime).ToList();
            if (recentRecords.Count > _maxRecordsInMemory)
            {
                recentRecords = recentRecords.OrderByDescending(r => r.Timestamp)
                                           .Take(_maxRecordsInMemory)
                                           .ToList();
            }
            lock (_lockObject)
            {
                _trafficRecords.Clear();
                foreach (var record in recentRecords)
                {
                    _trafficRecords.Add(record);
                }
            }

            Console.WriteLine($"清理完成，当前记录数: {_trafficRecords.Count}");
        }

        private string GenerateRealisticIP()
        {
            var baseIPs = _networkDevices.Select(d => d.IP).ToArray();
            if (_random.NextDouble() < 0.7 && baseIPs.Length > 0)
            {
                return baseIPs[_random.Next(baseIPs.Length)];
            }

            var segments = new[] { "192.168.1", "192.168.2", "192.168.3", "10.0.1", "172.16.1" };
            var segment = segments[_random.Next(segments.Length)];
            return $"{segment}.{_random.Next(1, 255)}";
        }

        private int GenerateRealisticSourcePort()
        {
            if (_random.NextDouble() < 0.3) 
            {
                var knownPorts = new[] { 80, 443, 502, 44818, 22, 21, 25, 53 };
                return knownPorts[_random.Next(knownPorts.Length)];
            }
            return _random.Next(1024, 65535);
        }

        private int GenerateRealisticDestinationPort()
        {
            var industrialPorts = new[] { 502, 44818, 2222, 4000, 4001, 4002 };
            var standardPorts = new[] { 80, 443, 22, 21, 25, 53, 1433, 3389 }; 

            if (_random.NextDouble() < 0.4) 
            {
                return industrialPorts[_random.Next(industrialPorts.Length)];
            }
            else if (_random.NextDouble() < 0.7) 
            {
                return standardPorts[_random.Next(standardPorts.Length)];
            }
            return _random.Next(8000, 9000); 
        }

        private NetworkProtocol GenerateWeightedProtocol()
        {
            // 加权协议选择，更符合工业环境  
            var rand = _random.NextDouble();
            if (rand < 0.25) return NetworkProtocol.TCP;
            if (rand < 0.40) return NetworkProtocol.UDP;
            if (rand < 0.55) return NetworkProtocol.HTTP;
            if (rand < 0.65) return NetworkProtocol.HTTPS;
            if (rand < 0.75) return NetworkProtocol.Modbus;
            if (rand < 0.85) return NetworkProtocol.EtherNetIP;
            if (rand < 0.92) return NetworkProtocol.OPCua;
            if (rand < 0.97) return NetworkProtocol.Profinet;
            return NetworkProtocol.EtherCAT;
        }

        private NetworkSegment GenerateWeightedSegment()
        {
            // 加权网络段选择  
            var rand = _random.NextDouble();
            if (rand < 0.35) return NetworkSegment.ControlNetwork;
            if (rand < 0.55) return NetworkSegment.OTNetwork;
            if (rand < 0.70) return NetworkSegment.ITNetwork;
            if (rand < 0.85) return NetworkSegment.DMZ;
            if (rand < 0.95) return NetworkSegment.SafetyNetwork;
            return NetworkSegment.WirelessNetwork;
        }

        private TrafficType DetermineRealisticTrafficType()
        {
            var rand = _random.NextDouble();
            var isNightTime = DateTime.Now.Hour < 6 || DateTime.Now.Hour > 22;
            var suspiciousMultiplier = isNightTime ? 2.0 : 1.0;

            if (rand < 0.88) return TrafficType.Normal;
            if (rand < 0.88 + (0.09 * suspiciousMultiplier)) return TrafficType.Suspicious;
            if (rand < 0.88 + (0.11 * suspiciousMultiplier)) return TrafficType.Malicious;
            return TrafficType.Emergency;
        }

        private double GenerateRealisticLatency()
        {
            var segment = GenerateWeightedSegment();
            var baseLatency = segment switch
            {
                NetworkSegment.ControlNetwork => _random.NextDouble() * 5 + 1,    
                NetworkSegment.SafetyNetwork => _random.NextDouble() * 3 + 1, 
                NetworkSegment.OTNetwork => _random.NextDouble() * 10 + 2,    
                NetworkSegment.ITNetwork => _random.NextDouble() * 15 + 5, 
                NetworkSegment.DMZ => _random.NextDouble() * 20 + 10,   
                NetworkSegment.WirelessNetwork => _random.NextDouble() * 30 + 15,
                _ => _random.NextDouble() * 10 + 2
            };
            if (_random.NextDouble() < 0.05)
            {
                baseLatency += _random.NextDouble() * 100 + 50;
            }

            return baseLatency;
        }

        private double GenerateRealisticPacketLoss()
        {
            // 正常情况下很低的丢包率  
            var baseLoss = _random.NextDouble() * 0.5; // 0-0.5%  

            // 2%概率出现较高丢包  
            if (_random.NextDouble() < 0.02)
            {
                baseLoss += _random.NextDouble() * 5 + 2; // 2-7%  
            }

            return baseLoss;
        }

        private string GetWeightedDeviceType()
        {
            // 加权设备类型选择  
            var types = new[] { "PLC", "HMI", "SCADA", "Robot", "VFD", "Sensor", "Gateway", "Switch", "Server" };
            var weights = new[] { 0.25, 0.15, 0.10, 0.10, 0.15, 0.10, 0.05, 0.05, 0.05 };

            var rand = _random.NextDouble();
            double cumulative = 0;

            for (int i = 0; i < weights.Length; i++)
            {
                cumulative += weights[i];
                if (rand <= cumulative)
                {
                    return types[i];
                }
            }

            return types[0];
        }

        private string GenerateDetailedAlertMessage(NetworkTrafficRecord record)
        {
            return record.TrafficType switch
            {
                TrafficType.Suspicious => $"检测到可疑流量模式: {record.Protocol} 协议，延迟 {record.Latency:F1}ms",
                TrafficType.Malicious => $"检测到恶意流量: 从 {record.SourceIP} 到 {record.DestinationIP}，可能的攻击行为",
                TrafficType.Emergency => $"紧急安全事件: 关键系统 {record.DestinationIP} 遭受攻击，立即响应",
                _ => ""
            };
        }

        private string GetThreatRecommendation(TrafficType trafficType)
        {
            return trafficType switch
            {
                TrafficType.Suspicious => "加强监控，记录详细日志，准备进一步调查",
                TrafficType.Malicious => "立即隔离相关设备，阻断可疑连接，启动事件响应流程",
                TrafficType.Emergency => "执行紧急响应计划，通知安全团队，考虑系统隔离",
                _ => "继续正常监控"
            };
        }

        private string GetMostTargetedIP(List<NetworkTrafficRecord> records, string sourceIP)
        {
            return records.Where(r => r.SourceIP == sourceIP)
                         .GroupBy(r => r.DestinationIP)
                         .OrderByDescending(g => g.Count())
                         .FirstOrDefault()?.Key ?? "Unknown";
        }

        // 保持原有的公共接口方法不变  
        private void InitializeIndustrialDevices()
        {
            var devices = new[]
            {
                new NetworkDevice { IP = "192.168.1.10", DeviceName = "PLC-001", DeviceType = "PLC", Segment = NetworkSegment.ControlNetwork, Vendor = "Siemens" },
                new NetworkDevice { IP = "192.168.1.11", DeviceName = "HMI-001", DeviceType = "HMI", Segment = NetworkSegment.ControlNetwork, Vendor = "Schneider" },
                new NetworkDevice { IP = "192.168.1.20", DeviceName = "SCADA-SRV", DeviceType = "SCADA Server", Segment = NetworkSegment.OTNetwork, Vendor = "GE" },
                new NetworkDevice { IP = "192.168.1.30", DeviceName = "Robot-001", DeviceType = "Industrial Robot", Segment = NetworkSegment.ControlNetwork, Vendor = "ABB" },
                new NetworkDevice { IP = "192.168.2.10", DeviceName = "VFD-001", DeviceType = "Variable Frequency Drive", Segment = NetworkSegment.ControlNetwork, Vendor = "Danfoss" },
                new NetworkDevice { IP = "192.168.3.10", DeviceName = "Safety-PLC", DeviceType = "Safety PLC", Segment = NetworkSegment.SafetyNetwork, Vendor = "Pilz" },
                new NetworkDevice { IP = "10.0.1.100", DeviceName = "ERP-Server", DeviceType = "ERP System", Segment = NetworkSegment.ITNetwork, Vendor = "SAP" },
                new NetworkDevice { IP = "172.16.1.50", DeviceName = "Historian", DeviceType = "Data Historian", Segment = NetworkSegment.DMZ, Vendor = "OSIsoft" }
            };

            foreach (var device in devices)
            {
                device.LastSeen = DateTime.Now.AddMinutes(_random.Next(-60, 0));
                device.IsOnline = _random.NextDouble() > 0.05;
                device.AverageLatency = _random.NextDouble() * 10 + 1;
                device.TotalTraffic = _random.Next(1000000, 10000000);
                device.OpenPorts = GenerateOpenPorts(device.DeviceType);
                device.FirmwareVersion = GenerateFirmwareVersion();

                _networkDevices.Add(device);
            }
        }

        public List<NetworkTrafficRecord> GetAllTrafficRecords() => _trafficRecords.ToList();
        public List<NetworkDevice> GetAllDevices() => _networkDevices.ToList();
        public List<NetworkThreat> GetAllThreats() => _detectedThreats.ToList();

        public List<NetworkTrafficRecord> GetTrafficByTimeRange(DateTime startTime, DateTime endTime)
        {
            return _trafficRecords.Where(r => r.Timestamp >= startTime && r.Timestamp <= endTime).ToList();
        }

        public List<NetworkTrafficRecord> GetTrafficBySegment(NetworkSegment segment)
        {
            return _trafficRecords.Where(r => r.Segment == segment).ToList();
        }

        public List<NetworkTrafficRecord> GetSuspiciousTraffic()
        {
            return _trafficRecords.Where(r => r.TrafficType != TrafficType.Normal).ToList();
        }

        public NetworkAnalysisReport GenerateAnalysisReport()
        {
            var now = DateTime.Now;
            var last24Hours = now.AddHours(-24);

            var recentTraffic = GetTrafficByTimeRange(last24Hours, now);
            var activeDevices = _networkDevices.Where(d => d.IsOnline).ToList();

            return new NetworkAnalysisReport
            {
                GeneratedTime = now,
                AnalysisPeriod = TimeSpan.FromHours(24),
                TotalTrafficRecords = recentTraffic.Count,
                ActiveDevices = activeDevices.Count,
                ThreatsDetected = _detectedThreats.Count(t => t.DetectedTime >= last24Hours),
                AverageLatency = recentTraffic.Any() ? recentTraffic.Average(r => r.Latency) : 0,
                AveragePacketLoss = recentTraffic.Any() ? recentTraffic.Average(r => r.PacketLoss) : 0,
                ProtocolDistribution = recentTraffic.GroupBy(r => r.Protocol)
                    .ToDictionary(g => g.Key, g => g.Count()),
                BandwidthBySegment = GenerateBandwidthReport(),
                CriticalThreats = _detectedThreats.Where(t => t.Severity == "Critical" && !t.IsResolved).ToList(),
                Recommendations = GenerateRecommendations()
            };
        }

        private List<string> GenerateOpenPorts(string deviceType)
        {
            return deviceType switch
            {
                "PLC" => new List<string> { "502", "44818" },
                "HMI" => new List<string> { "80", "443", "502" },
                "SCADA Server" => new List<string> { "80", "443", "1433", "502" },
                "Industrial Robot" => new List<string> { "502", "2222" },
                _ => new List<string> { "80", "443" }
            };
        }

        private string GenerateFirmwareVersion()
        {
            return $"v{_random.Next(1, 5)}.{_random.Next(0, 10)}.{_random.Next(0, 20)}";
        }

        private Dictionary<NetworkSegment, BandwidthUsage> GenerateBandwidthReport()
        {
            var result = new Dictionary<NetworkSegment, BandwidthUsage>();
            var segments = Enum.GetValues<NetworkSegment>();

            foreach (var segment in segments)
            {
                var totalBandwidth = segment switch
                {
                    NetworkSegment.ControlNetwork => 100_000_000,
                    NetworkSegment.OTNetwork => 1_000_000_000,
                    NetworkSegment.ITNetwork => 10_000_000_000,
                    _ => 100_000_000
                };

                var usedBandwidth = (long)(totalBandwidth * _random.NextDouble() * 0.8);

                result[segment] = new BandwidthUsage
                {
                    Segment = segment,
                    TimeStamp = DateTime.Now,
                    TotalBandwidth = totalBandwidth,
                    UsedBandwidth = usedBandwidth,
                    UtilizationPercentage = (double)usedBandwidth / totalBandwidth * 100,
                    ProtocolBreakdown = GenerateProtocolBreakdown(usedBandwidth)
                };
            }

            return result;
        }

        private Dictionary<NetworkProtocol, long> GenerateProtocolBreakdown(long totalUsed)
        {
            var protocols = new[] { NetworkProtocol.TCP, NetworkProtocol.UDP, NetworkProtocol.Modbus, NetworkProtocol.EtherNetIP };
            var result = new Dictionary<NetworkProtocol, long>();
            var remaining = totalUsed;

            for (int i = 0; i < protocols.Length - 1; i++)
            {
                var usage = (long)(remaining * _random.NextDouble() * 0.4);
                result[protocols[i]] = usage;
                remaining -= usage;
            }
            result[protocols[protocols.Length - 1]] = remaining;

            return result;
        }

        private List<string> GenerateRecommendations()
        {
            var recommendations = new List<string>();

            if (_detectedThreats.Any(t => t.Severity == "Critical" && !t.IsResolved))
                recommendations.Add("立即处理高危安全威胁");

            var highLatencyDevices = _networkDevices.Where(d => d.AverageLatency > 50).Count();
            if (highLatencyDevices > 0)
                recommendations.Add($"优化网络配置以降低延迟，受影响设备：{highLatencyDevices}台");

            var highUtilization = GenerateBandwidthReport().Values.Where(b => b.UtilizationPercentage > 80).Count();
            if (highUtilization > 0)
                recommendations.Add("考虑升级高利用率网络段的带宽");

            if (recommendations.Count == 0)
                recommendations.Add("网络运行状态良好，继续监控");

            return recommendations;
        }

        // 实时统计方法
        public RealTimeStatistics GetRealTimeStatistics()
        {
            var now = DateTime.Now;
            var lastMinute = now.AddMinutes(-1);
            var last5Minutes = now.AddMinutes(-5);
            var lastHour = now.AddHours(-1);

            var recentRecords = _trafficRecords.Where(r => r.Timestamp >= lastMinute).ToList();
            var last5MinRecords = _trafficRecords.Where(r => r.Timestamp >= last5Minutes).ToList();
            var lastHourRecords = _trafficRecords.Where(r => r.Timestamp >= lastHour).ToList();

            return new RealTimeStatistics
            {
                Timestamp = now,
                RecordsLastMinute = recentRecords.Count,
                RecordsLast5Minutes = last5MinRecords.Count,
                RecordsLastHour = lastHourRecords.Count,
                SuspiciousTrafficLastMinute = recentRecords.Count(r => r.TrafficType != TrafficType.Normal),
                AverageLatencyLastMinute = recentRecords.Any() ? recentRecords.Average(r => r.Latency) : 0,
                TotalBytesLastMinute = recentRecords.Sum(r => r.BytesSent + r.BytesReceived),
                ActiveDevicesCount = _networkDevices.Count(d => d.IsOnline),
                UnresolvedThreatsCount = _detectedThreats.Count(t => !t.IsResolved),
                ProtocolDistributionLastHour = lastHourRecords.GroupBy(r => r.Protocol)
                    .ToDictionary(g => g.Key.ToString(), g => g.Count())
            };
        }

        // 获取威胁趋势
        public List<ThreatTrend> GetThreatTrends(int hours = 24)
        {
            var cutoffTime = DateTime.Now.AddHours(-hours);
            var threats = _detectedThreats.Where(t => t.DetectedTime >= cutoffTime).ToList();

            return threats.GroupBy(t => new {
                Hour = t.DetectedTime.Hour,
                ThreatType = t.ThreatType
            })
                .Select(g => new ThreatTrend
                {
                    Hour = g.Key.Hour,
                    ThreatType = g.Key.ThreatType,
                    Count = g.Count(),
                    CriticalCount = g.Count(t => t.Severity == "Critical")
                })
                .OrderBy(t => t.Hour)
                .ToList();
        }

        // 获取设备健康状况
        public List<DeviceHealth> GetDeviceHealthStatus()
        {
            return _networkDevices.Select(d => new DeviceHealth
            {
                DeviceName = d.DeviceName,
                IP = d.IP,
                DeviceType = d.DeviceType,
                IsOnline = d.IsOnline,
                HealthScore = CalculateDeviceHealthScore(d),
                LastSeenMinutesAgo = (int)(DateTime.Now - d.LastSeen).TotalMinutes,
                AverageLatency = d.AverageLatency,
                TotalTrafficMB = d.TotalTraffic / (1024 * 1024),
                SecurityRisk = CalculateSecurityRisk(d)
            }).ToList();
        }

        private int CalculateDeviceHealthScore(NetworkDevice device)
        {
            int score = 100;

            if (!device.IsOnline) score -= 50;
            if (device.AverageLatency > 100) score -= 20;
            else if (device.AverageLatency > 50) score -= 10;

            var minutesSinceLastSeen = (DateTime.Now - device.LastSeen).TotalMinutes;
            if (minutesSinceLastSeen > 60) score -= 30;
            else if (minutesSinceLastSeen > 30) score -= 15;

            return Math.Max(0, score);
        }

        private int CalculateSecurityRisk(NetworkDevice device)
        {
            int risk = 0;

            // 开放端口多的设备风险更高
            risk += device.OpenPorts.Count * 10;

            // 关键设备类型风险更高
            if (device.DeviceType.Contains("PLC") || device.DeviceType.Contains("SCADA"))
                risk += 30;

            // 过时固件风险更高
            if (IsDeviceOutdated(device))
                risk += 25;

            // 离线设备风险较高
            if (!device.IsOnline)
                risk += 20;

            return Math.Min(100, risk);
        }

        private bool IsDeviceOutdated(NetworkDevice device)
        {
            return device.FirmwareVersion.StartsWith("v1.") || device.FirmwareVersion.StartsWith("v2.");
        }

        // 性能监控
        public void StartPerformanceMonitoring(Action<string> logCallback = null)
        {
            Task.Run(async () =>
            {
                while (!_disposed)
                {
                    try
                    {
                        var stats = GetRealTimeStatistics();
                        var message = $"[{DateTime.Now:HH:mm:ss}] " +
                                    $"Records/min: {stats.RecordsLastMinute}, " +
                                    $"Suspicious: {stats.SuspiciousTrafficLastMinute}, " +
                                    $"Avg Latency: {stats.AverageLatencyLastMinute:F1}ms, " +
                                    $"Threats: {stats.UnresolvedThreatsCount}";

                        logCallback?.Invoke(message);
                        Console.WriteLine(message);

                        await Task.Delay(10000); // 每10秒输出一次
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"性能监控错误: {ex.Message}");
                    }
                }
            });
        }

        // 资源清理
        private bool _disposed = false;

        public void Dispose()
        {
            if (!_disposed)
            {
                _trafficGenerationTimer?.Dispose();
                _threatDetectionTimer?.Dispose();
                _deviceStatusUpdateTimer?.Dispose();
                _disposed = true;

                Console.WriteLine("网络流量服务已停止");
            }
        }
    }

    // 辅助类定义
    public class RealTimeStatistics
    {
        public DateTime Timestamp { get; set; }
        public int RecordsLastMinute { get; set; }
        public int RecordsLast5Minutes { get; set; }
        public int RecordsLastHour { get; set; }
        public int SuspiciousTrafficLastMinute { get; set; }
        public double AverageLatencyLastMinute { get; set; }
        public long TotalBytesLastMinute { get; set; }
        public int ActiveDevicesCount { get; set; }
        public int UnresolvedThreatsCount { get; set; }
        public Dictionary<string, int> ProtocolDistributionLastHour { get; set; } = new();
    }

    public class ThreatTrend
    {
        public int Hour { get; set; }
        public string ThreatType { get; set; }
        public int Count { get; set; }
        public int CriticalCount { get; set; }
    }

    public class DeviceHealth
    {
        public string DeviceName { get; set; }
        public string IP { get; set; }
        public string DeviceType { get; set; }
        public bool IsOnline { get; set; }
        public int HealthScore { get; set; }
        public int LastSeenMinutesAgo { get; set; }
        public double AverageLatency { get; set; }
        public long TotalTrafficMB { get; set; }
        public int SecurityRisk { get; set; }
    }
}