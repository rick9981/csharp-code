﻿using System;
using System.Threading.Tasks;

namespace AppAiIndustryNetworkMonitor
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("🌐 实时工业网络流量智能分析系统 v2.0");
            Console.WriteLine("=========================================\n");

            // 创建服务实例
            using var networkService = new NetworkTrafficService();
            var aiAnalysisService = new AINetworkAnalysisService(networkService);

            // 启动性能监控
            networkService.StartPerformanceMonitoring();

            Console.WriteLine("✅ 实时数据生成已启动");
            Console.WriteLine("✅ AI分析服务已就绪");
            Console.WriteLine("✅ 威胁检测已启用");
            Console.WriteLine("\n输入命令或问题，输入 'help' 查看可用命令，输入 'exit' 退出\n");

            var chatHistory = new List<string>();

            while (true)
            {
                Console.Write("NetMonitor> ");
                var input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                    continue;

                if (input.ToLower() == "exit")
                {
                    Console.WriteLine("正在关闭服务...");
                    break;
                }

                if (input.ToLower() == "help")
                {
                    ShowHelp();
                    continue;
                }

                if (input.ToLower() == "stats")
                {
                    ShowRealTimeStats(networkService);
                    continue;
                }

                if (input.ToLower() == "devices")
                {
                    ShowDeviceHealth(networkService);
                    continue;
                }

                if (input.ToLower() == "threats")
                {
                    ShowThreats(networkService);
                    continue;
                }

                try
                {
                    Console.WriteLine("\n🤖 AI分析中...");
                    var response = await aiAnalysisService.AnalyzeAsync(input, chatHistory);

                    Console.WriteLine($"\n📊 分析结果：");
                    Console.WriteLine(response);
                    Console.WriteLine("\n" + new string('=', 80) + "\n");

                    // 更新聊天历史
                    chatHistory.Add(input);
                    chatHistory.Add(response);

                    if (chatHistory.Count > 20)
                    {
                        chatHistory.RemoveRange(0, 4);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ 分析过程中出现错误: {ex.Message}");
                }
            }

            Console.WriteLine("谢谢使用！");
        }

        private static void ShowHelp()
        {
            Console.WriteLine("\n📚 可用命令：");
            Console.WriteLine("  help    - 显示此帮助信息");
            Console.WriteLine("  stats   - 显示实时统计信息");
            Console.WriteLine("  devices - 显示设备健康状况");
            Console.WriteLine("  threats - 显示当前威胁列表");
            Console.WriteLine("  exit    - 退出程序");
            Console.WriteLine("\n💬 AI对话示例：");
            Console.WriteLine("  \"显示网络流量总览\"");
            Console.WriteLine("  \"分析最近的安全威胁\"");
            Console.WriteLine("  \"检查PLC设备状态\"");
            Console.WriteLine("  \"分析带宽利用率\"");
            Console.WriteLine("  \"检测协议异常\"\n");
        }

        private static void ShowRealTimeStats(NetworkTrafficService service)
        {
            var stats = service.GetRealTimeStatistics();
            Console.WriteLine("\n📈 实时统计信息：");
            Console.WriteLine($"  时间戳: {stats.Timestamp:yyyy-MM-dd HH:mm:ss}");
            Console.WriteLine($"  最近1分钟记录数: {stats.RecordsLastMinute}");
            Console.WriteLine($"  最近1小时记录数: {stats.RecordsLastHour}");
            Console.WriteLine($"  可疑流量(1分钟): {stats.SuspiciousTrafficLastMinute}");
            Console.WriteLine($"  平均延迟(1分钟): {stats.AverageLatencyLastMinute:F1}ms");
            Console.WriteLine($"  总流量(1分钟): {stats.TotalBytesLastMinute / 1024:N0} KB");
            Console.WriteLine($"  在线设备数: {stats.ActiveDevicesCount}");
            Console.WriteLine($"  未解决威胁数: {stats.UnresolvedThreatsCount}\n");
        }

        private static void ShowDeviceHealth(NetworkTrafficService service)
        {
            var devices = service.GetDeviceHealthStatus();
            Console.WriteLine("\n🔧 设备健康状况：");
            Console.WriteLine($"{"设备名",-15} {"IP地址",-15} {"状态",-8} {"健康度",-8} {"延迟",-8} {"风险",-6}");
            Console.WriteLine(new string('-', 70));

            foreach (var device in devices.OrderByDescending(d => d.HealthScore))
            {
                var status = device.IsOnline ? "在线" : "离线";
                var healthColor = device.HealthScore >= 80 ? "✅" : device.HealthScore >= 60 ? "⚠️" : "❌";
                var riskColor = device.SecurityRisk < 30 ? "🟢" : device.SecurityRisk < 60 ? "🟡" : "🔴";

                Console.WriteLine($"{device.DeviceName,-15} {device.IP,-15} {status,-8} {healthColor}{device.HealthScore,-7} {device.AverageLatency:F1}ms{"",-3} {riskColor}");
            }
            Console.WriteLine();
        }

        private static void ShowThreats(NetworkTrafficService service)
        {
            var threats = service.GetAllThreats().Where(t => !t.IsResolved).OrderByDescending(t => t.DetectedTime).Take(10).ToList();
            Console.WriteLine($"\n⚠️ 当前威胁列表 (最新10条)：");

            if (!threats.Any())
            {
                Console.WriteLine("  暂无未解决的威胁 ✅\n");
                return;
            }

            foreach (var threat in threats)
            {
                var severityIcon = threat.Severity switch
                {
                    "Critical" => "🔴",
                    "High" => "🟠",
                    "Medium" => "🟡",
                    _ => "🔵"
                };

                var timeAgo = DateTime.Now - threat.DetectedTime;
                var timeStr = timeAgo.TotalMinutes < 60 ? $"{(int)timeAgo.TotalMinutes}分钟前" : $"{(int)timeAgo.TotalHours}小时前";

                Console.WriteLine($"  {severityIcon} [{threat.ThreatType}] {threat.Description}");
                Console.WriteLine($"    来源: {threat.SourceIP} → 目标: {threat.TargetIP} | {timeStr}");
                Console.WriteLine($"    建议: {threat.RecommendedAction}\n");
            }
        }
    }
}