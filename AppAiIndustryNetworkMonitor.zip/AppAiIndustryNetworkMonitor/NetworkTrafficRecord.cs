﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAiIndustryNetworkMonitor
{
    public enum NetworkProtocol
    {
        TCP,
        UDP,
        ICMP,
        HTTP,
        HTTPS,
        Modbus,
        EtherNetIP,
        OPCua,
        Profinet,
        EtherCAT
    }

    public enum TrafficType
    {
        Normal,
        Suspicious,
        Malicious,
        Emergency
    }

    public enum NetworkSegment
    {
        OTNetwork,        // 操作技术网络
        ITNetwork,        // 信息技术网络
        DMZ,              // 非军事化区域
        ControlNetwork,   // 控制网络
        SafetyNetwork,    // 安全网络
        WirelessNetwork   // 无线网络
    }

    public class NetworkTrafficRecord
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public DateTime Timestamp { get; set; }
        public string SourceIP { get; set; }
        public string DestinationIP { get; set; }
        public int SourcePort { get; set; }
        public int DestinationPort { get; set; }
        public NetworkProtocol Protocol { get; set; }
        public long BytesSent { get; set; }
        public long BytesReceived { get; set; }
        public int PacketCount { get; set; }
        public double Duration { get; set; } // 秒
        public TrafficType TrafficType { get; set; }
        public NetworkSegment Segment { get; set; }
        public double Latency { get; set; } // 毫秒
        public double PacketLoss { get; set; } // 百分比
        public string DeviceType { get; set; }
        public string AlertMessage { get; set; }
        public Dictionary<string, object> CustomFields { get; set; } = new();
    }

    public class NetworkDevice
    {
        public string IP { get; set; }
        public string MACAddress { get; set; }
        public string DeviceName { get; set; }
        public string DeviceType { get; set; }
        public NetworkSegment Segment { get; set; }
        public DateTime LastSeen { get; set; }
        public bool IsOnline { get; set; }
        public double AverageLatency { get; set; }
        public long TotalTraffic { get; set; }
        public List<string> OpenPorts { get; set; } = new();
        public string Vendor { get; set; }
        public string FirmwareVersion { get; set; }
    }

    public class NetworkThreat
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public DateTime DetectedTime { get; set; }
        public string ThreatType { get; set; }
        public string Severity { get; set; }
        public string SourceIP { get; set; }
        public string TargetIP { get; set; }
        public string Description { get; set; }
        public string RecommendedAction { get; set; }
        public bool IsResolved { get; set; }
    }

    public class BandwidthUsage
    {
        public NetworkSegment Segment { get; set; }
        public DateTime TimeStamp { get; set; }
        public long TotalBandwidth { get; set; } // bps
        public long UsedBandwidth { get; set; } // bps
        public double UtilizationPercentage { get; set; }
        public Dictionary<NetworkProtocol, long> ProtocolBreakdown { get; set; } = new();
    }

    public class NetworkAnalysisReport
    {
        public DateTime GeneratedTime { get; set; }
        public TimeSpan AnalysisPeriod { get; set; }
        public int TotalTrafficRecords { get; set; }
        public int ActiveDevices { get; set; }
        public int ThreatsDetected { get; set; }
        public double AverageLatency { get; set; }
        public double AveragePacketLoss { get; set; }
        public Dictionary<NetworkProtocol, int> ProtocolDistribution { get; set; } = new();
        public Dictionary<NetworkSegment, BandwidthUsage> BandwidthBySegment { get; set; } = new();
        public List<NetworkThreat> CriticalThreats { get; set; } = new();
        public List<string> Recommendations { get; set; } = new();
    }
}
