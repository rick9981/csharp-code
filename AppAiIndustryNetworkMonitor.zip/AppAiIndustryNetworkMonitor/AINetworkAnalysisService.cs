﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;

namespace AppAiIndustryNetworkMonitor
{
    public class AINetworkAnalysisService
    {
        private readonly Kernel _kernel;
        private readonly NetworkTrafficService _networkService;

        public AINetworkAnalysisService(NetworkTrafficService networkService)
        {
            _networkService = networkService;
            _kernel = InitializeKernel();
            RegisterNetworkAnalysisPlugins();
        }

        private Kernel InitializeKernel()
        {
            var kernelBuilder = Kernel.CreateBuilder();

            kernelBuilder.AddOpenAIChatCompletion(
                modelId: "deepseek-chat",
                apiKey: Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY") ?? "sk-xxxxxx",
                endpoint: new Uri("https://api.deepseek.com/v1")
            );

            return kernelBuilder.Build();
        }

        private void RegisterNetworkAnalysisPlugins()
        {
            // 1. 网络流量总览插件
            var networkOverviewFunction = _kernel.CreateFunctionFromMethod(
                method: () =>
                {
                    var report = _networkService.GenerateAnalysisReport();
                    return JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "GetNetworkOverview",
                description: "获取网络流量分析总览，包括流量统计、设备状态、威胁检测和性能指标"
            );

            // 2. 安全威胁查询插件
            var threatAnalysisFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("威胁严重程度：Low, Medium, High, Critical，不填则返回所有威胁")] string severity = "") =>
                {
                    var threats = _networkService.GetAllThreats();

                    if (!string.IsNullOrEmpty(severity))
                    {
                        threats = threats.Where(t => t.Severity.Equals(severity, StringComparison.OrdinalIgnoreCase)).ToList();
                    }

                    var analysis = threats.Select(t => new
                    {
                        t.Id,
                        t.ThreatType,
                        t.Severity,
                        t.SourceIP,
                        t.TargetIP,
                        t.DetectedTime,
                        t.Description,
                        t.RecommendedAction,
                        t.IsResolved,
                        HoursAgo = (DateTime.Now - t.DetectedTime).TotalHours,
                        RiskScore = CalculateRiskScore(t)
                    })
                    .OrderByDescending(x => x.RiskScore)
                    .ToList();

                    return JsonSerializer.Serialize(new
                    {
                        TotalThreats = analysis.Count,
                        UnresolvedThreats = analysis.Count(a => !a.IsResolved),
                        CriticalThreats = analysis.Count(a => a.Severity == "Critical"),
                        Threats = analysis
                    }, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "AnalyzeSecurityThreats",
                description: "分析网络安全威胁，可按严重程度筛选，返回威胁详情和风险评分"
            );

            // 3. 网络设备监控插件
            var deviceMonitoringFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("网络段：OTNetwork, ITNetwork, DMZ, ControlNetwork, SafetyNetwork, WirelessNetwork")] string segment = "",
                         [Description("设备类型：PLC, HMI, SCADA, Robot等")] string deviceType = "") =>
                {
                    var devices = _networkService.GetAllDevices();

                    if (!string.IsNullOrEmpty(segment) && Enum.TryParse<NetworkSegment>(segment, true, out var seg))
                    {
                        devices = devices.Where(d => d.Segment == seg).ToList();
                    }

                    if (!string.IsNullOrEmpty(deviceType))
                    {
                        devices = devices.Where(d => d.DeviceType.Contains(deviceType, StringComparison.OrdinalIgnoreCase)).ToList();
                    }

                    var deviceStatus = devices.Select(d => new
                    {
                        d.IP,
                        d.DeviceName,
                        d.DeviceType,
                        d.Segment,
                        d.IsOnline,
                        d.LastSeen,
                        d.AverageLatency,
                        TotalTrafficMB = d.TotalTraffic / (1024 * 1024),
                        d.OpenPorts,
                        d.Vendor,
                        d.FirmwareVersion,
                        HealthScore = CalculateDeviceHealthScore(d),
                        SecurityRisk = CalculateSecurityRisk(d)
                    })
                    .OrderByDescending(x => x.SecurityRisk)
                    .ToList();

                    return JsonSerializer.Serialize(new
                    {
                        TotalDevices = deviceStatus.Count,
                        OnlineDevices = deviceStatus.Count(d => d.IsOnline),
                        HighRiskDevices = deviceStatus.Count(d => d.SecurityRisk > 70),
                        Devices = deviceStatus
                    }, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "MonitorNetworkDevices",
                description: "监控网络设备状态，可按网络段和设备类型筛选，评估设备健康度和安全风险"
            );

            // 4. 流量模式分析插件
            var trafficPatternFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("时间范围（小时）")] int hours = 24,
                         [Description("协议类型：TCP, UDP, HTTP, Modbus等")] string protocol = "") =>
                {
                    var endTime = DateTime.Now;
                    var startTime = endTime.AddHours(-hours);
                    var traffic = _networkService.GetTrafficByTimeRange(startTime, endTime);

                    if (!string.IsNullOrEmpty(protocol) && Enum.TryParse<NetworkProtocol>(protocol, true, out var proto))
                    {
                        traffic = traffic.Where(t => t.Protocol == proto).ToList();
                    }

                    var analysis = new
                    {
                        AnalysisPeriodHours = hours,
                        TotalRecords = traffic.Count,
                        TotalBytes = traffic.Sum(t => t.BytesSent + t.BytesReceived),
                        AverageLatency = traffic.Average(t => t.Latency),
                        AveragePacketLoss = traffic.Average(t => t.PacketLoss),

                        ProtocolDistribution = traffic.GroupBy(t => t.Protocol)
                            .ToDictionary(g => g.Key.ToString(), g => new
                            {
                                Count = g.Count(),
                                Percentage = (double)g.Count() / traffic.Count * 100,
                                TotalBytes = g.Sum(t => t.BytesSent + t.BytesReceived)
                            }),

                        SegmentDistribution = traffic.GroupBy(t => t.Segment)
                            .ToDictionary(g => g.Key.ToString(), g => new
                            {
                                Count = g.Count(),
                                Percentage = (double)g.Count() / traffic.Count * 100
                            }),

                        TrafficTypeDistribution = traffic.GroupBy(t => t.TrafficType)
                            .ToDictionary(g => g.Key.ToString(), g => g.Count()),

                        HourlyPattern = traffic.GroupBy(t => t.Timestamp.Hour)
                            .OrderBy(g => g.Key)
                            .ToDictionary(g => $"{g.Key:D2}:00", g => g.Count()),

                        TopTalkers = GetTopTalkers(traffic),
                        AnomalousTraffic = traffic.Where(t => t.TrafficType != TrafficType.Normal).Take(10).ToList()
                    };

                    return JsonSerializer.Serialize(analysis, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "AnalyzeTrafficPatterns",
                description: "分析网络流量模式，包括协议分布、时间模式、异常流量和主要通信节点"
            );

            // 5. 带宽利用率分析插件
            var bandwidthAnalysisFunction = _kernel.CreateFunctionFromMethod(
                method: () =>
                {
                    var report = _networkService.GenerateAnalysisReport();
                    var bandwidthData = report.BandwidthBySegment;

                    var analysis = bandwidthData.Select(kvp => new
                    {
                        Segment = kvp.Key.ToString(),
                        TotalBandwidthMbps = kvp.Value.TotalBandwidth / 1_000_000,
                        UsedBandwidthMbps = kvp.Value.UsedBandwidth / 1_000_000,
                        UtilizationPercentage = kvp.Value.UtilizationPercentage,
                        Status = GetBandwidthStatus(kvp.Value.UtilizationPercentage),
                        ProtocolBreakdown = kvp.Value.ProtocolBreakdown.ToDictionary(
                            pb => pb.Key.ToString(),
                            pb => pb.Value / 1_000_000 // 转换为Mbps
                        )
                    }).ToList();

                    return JsonSerializer.Serialize(new
                    {
                        OverallUtilization = analysis.Average(a => a.UtilizationPercentage),
                        SegmentsOverThreshold = analysis.Count(a => a.UtilizationPercentage > 80),
                        SegmentAnalysis = analysis,
                        Recommendations = GenerateBandwidthRecommendations(analysis)
                    }, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "AnalyzeBandwidthUtilization",
                description: "分析各网络段的带宽利用率，识别拥塞点和优化建议"
            );

            // 6. 协议异常检测插件
            var protocolAnomalyFunction = _kernel.CreateFunctionFromMethod(
                method: ([Description("协议类型：Modbus, EtherNetIP, OPCua, Profinet等工业协议")] string protocol = "") =>
                {
                    var traffic = _networkService.GetAllTrafficRecords();

                    if (!string.IsNullOrEmpty(protocol) && Enum.TryParse<NetworkProtocol>(protocol, true, out var proto))
                    {
                        traffic = traffic.Where(t => t.Protocol == proto).ToList();
                    }
                    else
                    {
                        // 只分析工业协议
                        var industrialProtocols = new[] { NetworkProtocol.Modbus, NetworkProtocol.EtherNetIP, NetworkProtocol.OPCua, NetworkProtocol.Profinet };
                        traffic = traffic.Where(t => industrialProtocols.Contains(t.Protocol)).ToList();
                    }

                    var anomalies = DetectProtocolAnomalies(traffic);

                    return JsonSerializer.Serialize(new
                    {
                        AnalyzedRecords = traffic.Count,
                        AnomaliesDetected = anomalies.Count,
                        Anomalies = anomalies.Select(a => new
                        {
                            a.Id,
                            a.Timestamp,
                            a.SourceIP,
                            a.DestinationIP,
                            a.Protocol,
                            a.AlertMessage,
                            AnomalyScore = CalculateAnomalyScore(a),
                            RecommendedAction = GetRecommendedAction(a)
                        }).OrderByDescending(x => x.AnomalyScore).ToList()
                    }, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "DetectProtocolAnomalies",
                description: "检测工业协议通信异常，识别潜在的安全威胁或设备故障"
            );

            // 7. 网络性能优化建议插件
            var optimizationFunction = _kernel.CreateFunctionFromMethod(
                method: () =>
                {
                    var report = _networkService.GenerateAnalysisReport();
                    var devices = _networkService.GetAllDevices();
                    var threats = _networkService.GetAllThreats();

                    var recommendations = new List<object>();

                    // 性能优化建议
                    if (report.AverageLatency > 50)
                        recommendations.Add(new
                        {
                            Type = "Performance",
                            Priority = "High",
                            Issue = "网络延迟过高",
                            Solution = "优化网络拓扑结构，考虑增加核心交换设备"
                        });

                    if (report.AveragePacketLoss > 2)
                        recommendations.Add(new
                        {
                            Type = "Performance",
                            Priority = "Medium",
                            Issue = "丢包率偏高",
                            Solution = "检查网络设备状态，优化QoS配置"
                        });

                    // 安全建议
                    var unresolvedThreats = threats.Where(t => !t.IsResolved).Count();
                    if (unresolvedThreats > 0)
                        recommendations.Add(new
                        {
                            Type = "Security",
                            Priority = "Critical",
                            Issue = $"存在{unresolvedThreats}个未解决的安全威胁",
                            Solution = "立即调查并处理所有安全威胁"
                        });

                    // 设备管理建议
                    var outdatedDevices = devices.Where(d => IsDeviceOutdated(d)).Count();
                    if (outdatedDevices > 0)
                        recommendations.Add(new
                        {
                            Type = "Maintenance",
                            Priority = "Medium",
                            Issue = $"{outdatedDevices}个设备可能需要固件更新",
                            Solution = "制定设备更新计划，确保安全补丁及时应用"
                        });

                    return JsonSerializer.Serialize(new
                    {
                        TotalRecommendations = recommendations.Count,
                        CriticalIssues = recommendations.Count(r => r.GetType().GetProperty("Priority").GetValue(r).ToString() == "Critical"),
                        OptimizationRecommendations = recommendations
                    }, new JsonSerializerOptions { WriteIndented = true });
                },
                functionName: "GenerateOptimizationRecommendations",
                description: "生成网络性能优化和安全改进建议"
            );

            // 注册插件到内核
            _kernel.ImportPluginFromFunctions("NetworkMonitoring", [networkOverviewFunction]);
            _kernel.ImportPluginFromFunctions("SecurityAnalysis", [threatAnalysisFunction]);
            _kernel.ImportPluginFromFunctions("DeviceManagement", [deviceMonitoringFunction]);
            _kernel.ImportPluginFromFunctions("TrafficAnalysis", [trafficPatternFunction, bandwidthAnalysisFunction]);
            _kernel.ImportPluginFromFunctions("ProtocolAnalysis", [protocolAnomalyFunction]);
            _kernel.ImportPluginFromFunctions("OptimizationAdvisor", [optimizationFunction]);
        }

        // 辅助方法实现
        private int CalculateRiskScore(NetworkThreat threat)
        {
            int score = threat.Severity switch
            {
                "Critical" => 90,
                "High" => 70,
                "Medium" => 40,
                "Low" => 20,
                _ => 10
            };

            // 未解决的威胁风险更高
            if (!threat.IsResolved) score += 20;

            // 最近的威胁风险更高
            var hoursAgo = (DateTime.Now - threat.DetectedTime).TotalHours;
            if (hoursAgo < 24) score += 10;

            return Math.Min(100, score);
        }

        private int CalculateDeviceHealthScore(NetworkDevice device)
        {
            int score = 100;

            if (!device.IsOnline) score -= 50;
            if (device.AverageLatency > 100) score -= 20;
            else if (device.AverageLatency > 50) score -= 10;

            var daysSinceLastSeen = (DateTime.Now - device.LastSeen).TotalDays;
            if (daysSinceLastSeen > 7) score -= 30;
            else if (daysSinceLastSeen > 1) score -= 10;

            return Math.Max(0, score);
        }

        private int CalculateSecurityRisk(NetworkDevice device)
        {
            int risk = 0;

            // 开放端口多的设备风险更高
            risk += device.OpenPorts.Count * 10;

            // 关键设备类型风险更高
            if (device.DeviceType.Contains("PLC") || device.DeviceType.Contains("SCADA"))
                risk += 30;

            // 过时固件风险更高
            if (IsDeviceOutdated(device))
                risk += 25;

            return Math.Min(100, risk);
        }

        private bool IsDeviceOutdated(NetworkDevice device)
        {
            // 简单的过时判断逻辑
            return device.FirmwareVersion.StartsWith("v1.") || device.FirmwareVersion.StartsWith("v2.");
        }

        private string GetBandwidthStatus(double utilization)
        {
            return utilization switch
            {
                > 90 => "Critical",
                > 80 => "Warning",
                > 60 => "Moderate",
                _ => "Normal"
            };
        }

        private List<object> GenerateBandwidthRecommendations<T>(List<T> analysis) where T : class
        {
            var recommendations = new List<object>();

            try
            {
                // 使用反射获取属性值，或者定义更具体的参数类型
                foreach (var item in analysis)
                {
                    var utilizationProperty = item.GetType().GetProperty("UtilizationPercentage");
                    var segmentProperty = item.GetType().GetProperty("Segment");

                    if (utilizationProperty != null && segmentProperty != null)
                    {
                        var utilization = (double)utilizationProperty.GetValue(item);
                        var segment = segmentProperty.GetValue(item).ToString();

                        if (utilization > 90)
                        {
                            recommendations.Add(new
                            {
                                Segment = segment,
                                Recommendation = "紧急扩容带宽或实施流量限制",
                                Priority = "Critical"
                            });
                        }
                        else if (utilization > 80)
                        {
                            recommendations.Add(new
                            {
                                Segment = segment,
                                Recommendation = "计划带宽升级",
                                Priority = "High"
                            });
                        }
                        else if (utilization > 60)
                        {
                            recommendations.Add(new
                            {
                                Segment = segment,
                                Recommendation = "监控带宽使用趋势",
                                Priority = "Medium"
                            });
                        }
                    }
                }
            }
            catch
            {
                // 如果反射失败，提供默认建议
                recommendations.Add(new { Recommendation = "监控带宽使用趋势", Priority = "Medium" });
            }

            if (recommendations.Count == 0)
            {
                recommendations.Add(new { Recommendation = "带宽利用率正常，继续监控", Priority = "Low" });
            }

            return recommendations;
        }

        private List<NetworkTrafficRecord> DetectProtocolAnomalies(List<NetworkTrafficRecord> traffic)
        {
            // 简单的异常检测逻辑
            return traffic.Where(t =>
                t.TrafficType != TrafficType.Normal ||
                t.Latency > 100 ||
                t.PacketLoss > 5
            ).ToList();
        }

        private int CalculateAnomalyScore(NetworkTrafficRecord record)
        {
            int score = 0;

            switch (record.TrafficType)
            {
                case TrafficType.Emergency: score += 90; break;
                case TrafficType.Malicious: score += 70; break;
                case TrafficType.Suspicious: score += 40; break;
            }

            if (record.Latency > 100) score += 20;
            if (record.PacketLoss > 5) score += 15;

            return Math.Min(100, score);
        }

        private string GetRecommendedAction(NetworkTrafficRecord record)
        {
            return record.TrafficType switch
            {
                TrafficType.Emergency => "立即隔离相关设备并调查",
                TrafficType.Malicious => "阻断可疑连接并进行深度分析",
                TrafficType.Suspicious => "加强监控并记录详细日志",
                _ => "继续观察"
            };
        }

        private List<object> GetTopTalkers(List<NetworkTrafficRecord> traffic)
        {
            return traffic
                .GroupBy(t => t.SourceIP)
                .Select(g => new
                {
                    IP = g.Key,
                    TotalBytes = g.Sum(t => t.BytesSent + t.BytesReceived),
                    SessionCount = g.Count()
                })
                .OrderByDescending(x => x.TotalBytes)
                .Take(10)
                .ToList<object>();
        }

        public async Task<string> AnalyzeAsync(string userMessage, List<string> chatHistory = null)
        {
            var chatCompletionService = _kernel.GetRequiredService<IChatCompletionService>();

            var systemMessage = @"你是一位专业的工业网络安全和性能分析专家。你具备以下专业能力：

🔒 **网络安全分析**
- 实时威胁检测与分析
- 入侵检测和异常行为识别
- 工业协议安全评估
- 安全事件响应建议

📊 **网络性能监控**
- 流量模式分析和趋势预测
- 带宽利用率优化
- 延迟和丢包分析
- 网络瓶颈识别

🏭 **工业网络专业知识**
- OT/IT网络架构安全
- 工业协议分析（Modbus、EtherNet/IP、OPC-UA等）
- SCADA/PLC通信监控
- 关键基础设施保护

⚡ **智能诊断能力**
- 基于ML的异常检测
- 预测性网络维护
- 自动化安全响应建议
- 网络优化策略制定

**分析重点**：
- 优先关注安全威胁和性能瓶颈
- 提供可操作的具体建议
- 考虑工业环境的特殊需求
- 平衡安全性与业务连续性

请根据用户的询问提供专业的网络分析和建议。对于紧急安全事件，会优先提供应急响应指导。";

            var history = new Microsoft.SemanticKernel.ChatCompletion.ChatHistory();
            history.AddSystemMessage(systemMessage);

            // 添加聊天历史
            if (chatHistory != null && chatHistory.Count > 0)
            {
                for (int i = 0; i < chatHistory.Count; i += 2)
                {
                    if (i < chatHistory.Count)
                        history.AddUserMessage(chatHistory[i]);
                    if (i + 1 < chatHistory.Count)
                        history.AddAssistantMessage(chatHistory[i + 1]);
                }
            }

            history.AddUserMessage(userMessage);

            var executionSettings = new OpenAIPromptExecutionSettings
            {
                ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions,
                MaxTokens = 2500,
                Temperature = 0.2 // 较低温度确保分析的准确性
            };

            var response = await chatCompletionService.GetChatMessageContentAsync(
                history,
                executionSettings,
                _kernel
            );

            return response.Content;
        }
    }
}
