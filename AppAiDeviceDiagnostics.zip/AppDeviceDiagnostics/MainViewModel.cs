﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AppDeviceDiagnostics
{
    public class ChatMessage
    {
        public string Message { get; set; }
        public string Sender { get; set; }
        public DateTime Timestamp { get; set; }
        public bool IsUser { get; set; }
    }

    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly DeviceService _deviceService;
        private readonly AIDiagnosticService _aiService;

        private ObservableCollection<Device> _devices;
        private Device _selectedDevice;
        private string _currentMessage;
        private ObservableCollection<ChatMessage> _chatMessages;
        private List<string> _chatHistory;

        // 状态统计
        private int _runningCount;
        private int _warningCount;
        private int _errorCount;
        private int _offlineCount;
        private string _systemSummary;

        public MainViewModel()
        {
            _deviceService = new DeviceService();
            _aiService = new AIDiagnosticService(_deviceService);
            _chatMessages = new ObservableCollection<ChatMessage>();
            _chatHistory = new List<string>();

            InitializeCommands();
            LoadDevices();
            SubscribeToDeviceEvents();

            // 添加欢迎消息
            AddChatMessage("欢迎使用设备运行状态实时诊断系统！\n\n我可以帮您：\n• 监控设备运行状态\n• 诊断设备故障\n• 提供维护建议\n• 分析设备性能\n\n请告诉我您需要什么帮助？", "AI助手", false);
        }

        #region Properties

        public ObservableCollection<Device> Devices
        {
            get => _devices;
            set { _devices = value; OnPropertyChanged(); }
        }

        public Device SelectedDevice
        {
            get => _selectedDevice;
            set { _selectedDevice = value; OnPropertyChanged(); }
        }

        public string CurrentMessage
        {
            get => _currentMessage;
            set { _currentMessage = value; OnPropertyChanged(); }
        }

        public ObservableCollection<ChatMessage> ChatMessages
        {
            get => _chatMessages;
            set { _chatMessages = value; OnPropertyChanged(); }
        }

        public int RunningCount
        {
            get => _runningCount;
            set { _runningCount = value; OnPropertyChanged(); }
        }

        public int WarningCount
        {
            get => _warningCount;
            set { _warningCount = value; OnPropertyChanged(); }
        }

        public int ErrorCount
        {
            get => _errorCount;
            set { _errorCount = value; OnPropertyChanged(); }
        }

        public int OfflineCount
        {
            get => _offlineCount;
            set { _offlineCount = value; OnPropertyChanged(); }
        }

        public string SystemSummary
        {
            get => _systemSummary;
            set { _systemSummary = value; OnPropertyChanged(); }
        }

        #endregion

        #region Commands

        public ICommand SendMessageCommand { get; private set; }
        public ICommand QuickQueryCommand { get; private set; }

        private void InitializeCommands()
        {
            SendMessageCommand = new RelayCommand(async () => await SendMessage(), () => !string.IsNullOrWhiteSpace(CurrentMessage));
            QuickQueryCommand = new RelayCommand<string>(async (query) => await ProcessQuickQuery(query));
        }

        #endregion

        #region Methods

        private void LoadDevices()
        {
            Devices = new ObservableCollection<Device>(_deviceService.GetAllDevices());
            UpdateStatusCounts();
        }

        private void SubscribeToDeviceEvents()
        {
            _deviceService.DeviceStatusChanged += OnDeviceStatusChanged;
            _deviceService.DiagnosticReportGenerated += OnDiagnosticReportGenerated;
        }

        private void OnDeviceStatusChanged(object sender, Device device)
        {
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                var existingDevice = Devices.FirstOrDefault(d => d.Id == device.Id);
                if (existingDevice != null)
                {
                    var index = Devices.IndexOf(existingDevice);
                    Devices[index] = device;

                    if (SelectedDevice?.Id == device.Id)
                    {
                        SelectedDevice = device;
                    }
                }
                UpdateStatusCounts();
            });
        }

        private void OnDiagnosticReportGenerated(object sender, DiagnosticReport report)
        {
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                RunningCount = report.RunningDevices;
                WarningCount = report.WarningDevices;
                ErrorCount = report.ErrorDevices;
                OfflineCount = report.OfflineDevices;
                SystemSummary = report.Summary;
            });
        }

        private void UpdateStatusCounts()
        {
            if (Devices != null)
            {
                RunningCount = Devices.Count(d => d.Status == DeviceStatus.Running);
                WarningCount = Devices.Count(d => d.Status == DeviceStatus.Warning);
                ErrorCount = Devices.Count(d => d.Status == DeviceStatus.Error);
                OfflineCount = Devices.Count(d => d.Status == DeviceStatus.Offline);

                SystemSummary = ErrorCount + OfflineCount > 0 ?
                    $"系统存在 {ErrorCount + OfflineCount} 个严重问题，需要立即处理" :
                    WarningCount > 0 ? $"系统有 {WarningCount} 个设备需要关注" : "所有设备运行正常";
            }
        }

        private async Task SendMessage()
        {
            if (string.IsNullOrWhiteSpace(CurrentMessage)) return;

            var userMessage = CurrentMessage.Trim();
            CurrentMessage = string.Empty;

            AddChatMessage(userMessage, "用户", true);

            try
            {
                var response = await _aiService.DiagnoseAsync(userMessage, _chatHistory);
                AddChatMessage(response, "AI助手", false);

                // 更新聊天历史
                _chatHistory.Add(userMessage);
                _chatHistory.Add(response);

                // 保持历史记录在合理长度
                if (_chatHistory.Count > 20)
                {
                    _chatHistory.RemoveRange(0, 4);
                }
            }
            catch (Exception ex)
            {
                AddChatMessage($"抱歉，处理您的请求时发生错误：{ex.Message}", "系统", false);
            }
        }

        private async Task ProcessQuickQuery(string query)
        {
            if (string.IsNullOrEmpty(query)) return;

            AddChatMessage(query, "用户", true);

            try
            {
                var response = await _aiService.DiagnoseAsync(query, _chatHistory);
                AddChatMessage(response, "AI助手", false);

                _chatHistory.Add(query);
                _chatHistory.Add(response);

                if (_chatHistory.Count > 20)
                {
                    _chatHistory.RemoveRange(0, 4);
                }
            }
            catch (Exception ex)
            {
                AddChatMessage($"抱歉，处理您的请求时发生错误：{ex.Message}", "系统", false);
            }
        }

        private void AddChatMessage(string message, string sender, bool isUser)
        {
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                ChatMessages.Add(new ChatMessage
                {
                    Message = message,
                    Sender = sender,
                    Timestamp = DateTime.Now,
                    IsUser = isUser
                });

                // 限制聊天消息数量
                while (ChatMessages.Count > 100)
                {
                    ChatMessages.RemoveAt(0);
                }
            });
        }

        #endregion

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }

    // 简单的RelayCommand实现
    public class RelayCommand : ICommand
    {
        private readonly Func<Task> _executeAsync;
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public RelayCommand(Func<Task> executeAsync, Func<bool> canExecute = null)
        {
            _executeAsync = executeAsync ?? throw new ArgumentNullException(nameof(executeAsync));
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter) => _canExecute?.Invoke() ?? true;

        public async void Execute(object parameter)
        {
            if (_executeAsync != null)
                await _executeAsync();
            else
                _execute?.Invoke();
        }
    }

    public class RelayCommand<T> : ICommand
    {
        private readonly Func<T, Task> _executeAsync;
        private readonly Action<T> _execute;
        private readonly Func<T, bool> _canExecute;

        public RelayCommand(Action<T> execute, Func<T, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public RelayCommand(Func<T, Task> executeAsync, Func<T, bool> canExecute = null)
        {
            _executeAsync = executeAsync ?? throw new ArgumentNullException(nameof(executeAsync));
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter) => _canExecute?.Invoke((T)parameter) ?? true;

        public async void Execute(object parameter)
        {
            if (_executeAsync != null)
                await _executeAsync((T)parameter);
            else
                _execute?.Invoke((T)parameter);
        }
    }
}
