﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Timer = System.Timers.Timer;

namespace AppDeviceDiagnostics
{
    public class DeviceService
    {
        private readonly List<Device> _devices;
        private readonly Timer _simulationTimer;
        private readonly Random _random;

        public event EventHandler<Device> DeviceStatusChanged;
        public event EventHandler<DiagnosticReport> DiagnosticReportGenerated;

        public DeviceService()
        {
            _devices = new List<Device>();
            _random = new Random();
            InitializeDevices();

            _simulationTimer = new Timer(3000); // 每3秒更新一次数据
            _simulationTimer.Elapsed += SimulateDeviceData;
            _simulationTimer.Start();
        }

        private void InitializeDevices()
        {
            _devices.AddRange(new[]
            {
                new Device
                {
                    Id = "DEV001", Name = "主电机", Type = DeviceType.Motor,
                    Status = DeviceStatus.Running, Location = "生产线A",
                    Temperature = 75, Pressure = 2.5, Vibration = 0.3,
                    RunningHours = 1240, LastMaintenance = DateTime.Now.AddDays(-30)
                },
                new Device
                {
                    Id = "DEV002", Name = "冷却泵", Type = DeviceType.Pump,
                    Status = DeviceStatus.Running, Location = "冷却系统",
                    Temperature = 45, Pressure = 3.2, Vibration = 0.1,
                    RunningHours = 2100, LastMaintenance = DateTime.Now.AddDays(-15)
                },
                new Device
                {
                    Id = "DEV003", Name = "温度传感器", Type = DeviceType.Sensor,
                    Status = DeviceStatus.Warning, Location = "车间B",
                    Temperature = 25, Pressure = 0, Vibration = 0,
                    RunningHours = 8760, LastMaintenance = DateTime.Now.AddDays(-90),
                    ErrorMessage = "读数异常波动"
                },
                new Device
                {
                    Id = "DEV004", Name = "PLC控制器", Type = DeviceType.Controller,
                    Status = DeviceStatus.Running, Location = "控制室",
                    Temperature = 35, Pressure = 0, Vibration = 0,
                    RunningHours = 3600, LastMaintenance = DateTime.Now.AddDays(-60)
                },
                new Device
                {
                    Id = "DEV005", Name = "辅助电机", Type = DeviceType.Motor,
                    Status = DeviceStatus.Error, Location = "生产线B",
                    Temperature = 95, Pressure = 1.8, Vibration = 1.5,
                    RunningHours = 5200, LastMaintenance = DateTime.Now.AddDays(-120),
                    ErrorMessage = "温度过高，振动异常"
                }
            });
        }

        private void SimulateDeviceData(object sender, ElapsedEventArgs e)
        {
            foreach (var device in _devices)
            {
                var oldStatus = device.Status;

                // 模拟数据变化
                device.Temperature += _random.NextDouble() * 4 - 2; // ±2度变化
                device.Pressure += _random.NextDouble() * 0.2 - 0.1; // ±0.1变化
                device.Vibration += _random.NextDouble() * 0.1 - 0.05; // ±0.05变化
                device.RunningHours += _random.Next(0, 2); // 运行小时数增加

                // 确保数据在合理范围内
                device.Temperature = Math.Max(0, Math.Min(150, device.Temperature));
                device.Pressure = Math.Max(0, Math.Min(10, device.Pressure));
                device.Vibration = Math.Max(0, Math.Min(5, device.Vibration));

                // 根据参数判断设备状态
                UpdateDeviceStatus(device);

                // 如果状态改变，触发事件
                if (device.Status != oldStatus)
                {
                    DeviceStatusChanged?.Invoke(this, device);
                }
            }

            // 生成诊断报告
            var report = GenerateAnalysisReport();
            DiagnosticReportGenerated?.Invoke(this, report);
        }

        private void UpdateDeviceStatus(Device device)
        {
            var previousStatus = device.Status;
            device.ErrorMessage = "";

            // 离线检测（随机模拟）
            if (_random.NextDouble() < 0.02) // 2%概率离线
            {
                device.Status = DeviceStatus.Offline;
                device.ErrorMessage = "设备离线";
                return;
            }

            // 错误检测
            bool hasError = false;
            var errorMessages = new List<string>();

            if (device.Temperature > 90)
            {
                hasError = true;
                errorMessages.Add("温度过高");
            }

            if (device.Vibration > 1.0)
            {
                hasError = true;
                errorMessages.Add("振动异常");
            }

            if (device.Type == DeviceType.Pump && device.Pressure < 1.0)
            {
                hasError = true;
                errorMessages.Add("压力不足");
            }

            if (hasError)
            {
                device.Status = DeviceStatus.Error;
                device.ErrorMessage = string.Join(", ", errorMessages);
                return;
            }

            // 警告检测
            bool hasWarning = false;
            var warningMessages = new List<string>();

            if (device.Temperature > 80)
            {
                hasWarning = true;
                warningMessages.Add("温度较高");
            }

            if (device.Vibration > 0.7)
            {
                hasWarning = true;
                warningMessages.Add("振动偏高");
            }

            if ((DateTime.Now - device.LastMaintenance).TotalDays > 90)
            {
                hasWarning = true;
                warningMessages.Add("需要保养");
            }

            if (hasWarning)
            {
                device.Status = DeviceStatus.Warning;
                device.ErrorMessage = string.Join(", ", warningMessages);
                return;
            }

            // 正常状态
            device.Status = DeviceStatus.Running;
        }

        public List<Device> GetAllDevices() => _devices.ToList();

        public Device GetDevice(string deviceId) =>
            _devices.FirstOrDefault(d => d.Id == deviceId);

        public List<Device> GetDevicesByStatus(DeviceStatus status) =>
            _devices.Where(d => d.Status == status).ToList();

        public DiagnosticReport GenerateAnalysisReport()
        {
            return new DiagnosticReport
            {
                Timestamp = DateTime.Now,
                TotalDevices = _devices.Count,
                RunningDevices = _devices.Count(d => d.Status == DeviceStatus.Running),
                WarningDevices = _devices.Count(d => d.Status == DeviceStatus.Warning),
                ErrorDevices = _devices.Count(d => d.Status == DeviceStatus.Error),
                OfflineDevices = _devices.Count(d => d.Status == DeviceStatus.Offline),
                CriticalDevices = _devices.Where(d => d.Status == DeviceStatus.Error || d.Status == DeviceStatus.Offline).ToList(),
                Summary = GenerateSummary()
            };
        }

        private string GenerateSummary()
        {
            var errorCount = _devices.Count(d => d.Status == DeviceStatus.Error);
            var warningCount = _devices.Count(d => d.Status == DeviceStatus.Warning);
            var offlineCount = _devices.Count(d => d.Status == DeviceStatus.Offline);

            if (errorCount > 0 || offlineCount > 0)
                return $"系统存在 {errorCount + offlineCount} 个严重问题，需要立即处理";
            else if (warningCount > 0)
                return $"系统有 {warningCount} 个设备需要关注";
            else
                return "所有设备运行正常";
        }

        public void Dispose()
        {
            _simulationTimer?.Stop();
            _simulationTimer?.Dispose();
        }
    }
}
