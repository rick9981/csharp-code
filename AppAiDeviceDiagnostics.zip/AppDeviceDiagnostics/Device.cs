﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDeviceDiagnostics
{
    public enum DeviceStatus
    {
        Running,    // 运行中
        Warning,    // 警告
        Error,      // 故障
        Offline     // 离线
    }

    public enum DeviceType
    {
        Motor,      // 电机
        Pump,       // 泵
        Sensor,     // 传感器
        Controller  // 控制器
    }

    public class Device : INotifyPropertyChanged
    {
        private string _id;
        private string _name;
        private DeviceType _type;
        private DeviceStatus _status;
        private double _temperature;
        private double _pressure;
        private double _vibration;
        private int _runningHours;
        private DateTime _lastMaintenance;
        private string _location;
        private string _errorMessage;

        public string Id
        {
            get => _id;
            set { _id = value; OnPropertyChanged(nameof(Id)); }
        }

        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(nameof(Name)); }
        }

        public DeviceType Type
        {
            get => _type;
            set { _type = value; OnPropertyChanged(nameof(Type)); }
        }

        public DeviceStatus Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(nameof(Status)); }
        }

        public double Temperature
        {
            get => _temperature;
            set { _temperature = value; OnPropertyChanged(nameof(Temperature)); }
        }

        public double Pressure
        {
            get => _pressure;
            set { _pressure = value; OnPropertyChanged(nameof(Pressure)); }
        }

        public double Vibration
        {
            get => _vibration;
            set { _vibration = value; OnPropertyChanged(nameof(Vibration)); }
        }

        public int RunningHours
        {
            get => _runningHours;
            set { _runningHours = value; OnPropertyChanged(nameof(RunningHours)); }
        }

        public DateTime LastMaintenance
        {
            get => _lastMaintenance;
            set { _lastMaintenance = value; OnPropertyChanged(nameof(LastMaintenance)); }
        }

        public string Location
        {
            get => _location;
            set { _location = value; OnPropertyChanged(nameof(Location)); }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(nameof(ErrorMessage)); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class DiagnosticReport
    {
        public DateTime Timestamp { get; set; }
        public int TotalDevices { get; set; }
        public int RunningDevices { get; set; }
        public int WarningDevices { get; set; }
        public int ErrorDevices { get; set; }
        public int OfflineDevices { get; set; }
        public List<Device> CriticalDevices { get; set; } = new List<Device>();
        public string Summary { get; set; }
    }
}
